import os
from typing import Tuple

import numpy as np
from skimage import measure
import trimesh

import torch
import torch.nn.functional as TF


class TSDF:

    # Ensures the final voxel volume dimensions are multiples of 8
    VOX_MOD = 8

    def __init__(self,
                 voxel_coords: torch.tensor,
                 tsdf_values: torch.tensor,
                 tsdf_weights: torch.tensor,
                 voxel_size: float,
                 origin: torch.tensor):

        self.voxel_coords = voxel_coords.half()
        self.tsdf_values = tsdf_values.half()
        self.tsdf_weights = tsdf_weights.half()
        self.voxel_size = voxel_size
        self.origin = origin.half()

    @classmethod
    def from_file(cls, tsdf_file):

        tsdf_data = np.load(tsdf_file)

        tsdf_values = torch.from_numpy(tsdf_data['tsdf_values'])
        origin = torch.from_numpy(tsdf_data['origin'])
        voxel_size = tsdf_data['voxel_size'].item()

        tsdf_weights = torch.ones_like(tsdf_values)

        voxel_coords = cls.generate_voxel_coords(origin, tsdf_values.shape[1:], voxel_size)

        return TSDF(voxel_coords, tsdf_values, tsdf_weights, voxel_size)

    @classmethod
    def from_mesh(cls, mesh: trimesh.Trimesh, voxel_size: float):
        xmax, ymax, zmax = mesh.vertices.max(0)
        xmin, ymin, zmin = mesh.vertices.min(0)

        bounds = {'xmin': xmin, 'xmax': xmax,
                  'ymin': ymin, 'ymax': ymax,
                  'zmin': zmin, 'zmax': zmax}

        # create a buffer around bounds
        for key, val in bounds.items():
            if 'min' in key:
                bounds[key] = val - 3 * voxel_size
            else:
                bounds[key] = val + 3 * voxel_size
        return cls.from_bounds(bounds, voxel_size)

    @classmethod
    def from_bounds(cls, bounds: dict, voxel_size: float):
        expected_keys = ['xmin', 'xmax', 'ymin', 'ymax', 'zmin', 'zmax']
        for key in expected_keys:
            if key not in bounds.keys():
                raise KeyError("Provided bounds dict need to have keys"
                               "'xmin', 'xmax', 'ymin', 'ymax', 'zmin', 'zmax'!")

        num_voxels_x = int(
            np.ceil((bounds['xmax'] - bounds['xmin']) / voxel_size / cls.VOX_MOD)) * cls.VOX_MOD
        num_voxels_y = int(
            np.ceil((bounds['ymax'] - bounds['ymin']) / voxel_size / cls.VOX_MOD)) * cls.VOX_MOD
        num_voxels_z = int(
            np.ceil((bounds['zmax'] - bounds['zmin']) / voxel_size / cls.VOX_MOD)) * cls.VOX_MOD

        origin = torch.FloatTensor([bounds['xmin'], bounds['ymin'], bounds['zmin']])

        voxel_coords = cls.generate_voxel_coords(
            origin, (num_voxels_x, num_voxels_y, num_voxels_z), voxel_size).half()

        # init to -1s
        tsdf_values = -torch.ones_like(voxel_coords[0]).half()
        tsdf_weights = torch.zeros_like(voxel_coords[0]).half()

        return TSDF(voxel_coords, tsdf_values, tsdf_weights, voxel_size, origin)

    @classmethod
    def generate_voxel_coords(cls,
                              origin: torch.tensor,
                              volume_dims: Tuple[int, int, int],
                              voxel_size: float):

        grid = torch.meshgrid([torch.arange(vd) for vd in volume_dims])

        voxel_coords = origin.view(3, 1, 1, 1) + torch.stack(grid, 0) * voxel_size

        return voxel_coords


    def cuda(self):
        self.voxel_coords = self.voxel_coords.cuda()
        self.tsdf_values = self.tsdf_values.cuda()
        if self.tsdf_weights is not None:
            self.tsdf_weights = self.tsdf_weights.cuda()

    def cpu(self):
        self.voxel_coords = self.voxel_coords.cpu()
        self.tsdf_values = self.tsdf_values.cpu()
        if self.tsdf_weights is not None:
            self.tsdf_weights = self.tsdf_weights.cpu()

    def to_mesh(self, scale_to_world=True, export_single_mesh=False):

        # self.cpu()

        tsdf = self.tsdf_values.detach().cpu().clone().float()
        # tsdf[tsdf == -1] = 1.0
        tsdf_np = tsdf.clamp(-1, 1).cpu().numpy()

        if export_single_mesh:
            # mask = (self.tsdf_weights > 0).cpu().numpy()
            # mask = (torch.nn.MaxPool3d(kernel_size=3, stride=1, padding=1)(-self.tsdf_weights[None,:].float()) != 0).squeeze(0).cpu().numpy()
            verts, faces, norms, _ = measure.marching_cubes(tsdf_np, level=0, allow_degenerate=False, single_mesh = True)
        else:
            verts, faces, norms, _ = measure.marching_cubes(tsdf_np, level=0, allow_degenerate=False)

        if scale_to_world:
            verts = self.origin.cpu().view(1, 3) + verts * self.voxel_size

        mesh = trimesh.Trimesh(vertices=verts, faces=faces, normals=norms)
        return mesh

    def save(self, savepath, filename, save_mesh=False):
        self.cpu()
        os.makedirs(savepath, exist_ok=True)

        data_dict = {
            "tsdf_values": self.tsdf_values.numpy().astype(np.float16),
            "origin": self.origin.numpy(),
            "voxel_size": self.voxel_size,
        }
        # compressed_blob = lz4framed.compress(pyarrow.serialize(data_dict).to_buffer())
        # with open(os.path.join(savepath, filename), "wb") as f:
        #     f.write(compressed_blob)

        if save_mesh:
            mesh = self.to_mesh()
            trimesh.exchange.export.export_mesh(
                mesh, os.path.join(savepath, filename).replace(".bin", ".ply"), "ply")


class TSDFFuser:
    def __init__(self, tsdf, min_depth=0.5, max_depth=5.0, use_gpu=True):

        self.tsdf = tsdf
        self.min_depth = min_depth
        self.max_depth = max_depth
        self.use_gpu = use_gpu
        self.truncation_size = 3.0
        self.maxW = 100.0

        # Create homogeneous coords once only
        self.hom_voxel_coords_14hwd = torch.cat(
            (self.voxel_coords, torch.ones_like(self.voxel_coords[:1])), 0).unsqueeze(0)

    @property
    def voxel_coords(self):
        return self.tsdf.voxel_coords

    @property
    def tsdf_values(self):
        return self.tsdf.tsdf_values

    @property
    def tsdf_weights(self):
        return self.tsdf.tsdf_weights

    @property
    def voxel_size(self):
        return self.tsdf.voxel_size

    @property
    def shape(self):
        return self.voxel_coords.shape[1:]

    @property
    def truncation(self):
        return self.truncation_size * self.voxel_size

    def project_to_camera(self, world_to_cam_T_b44, K_b44):

        if self.use_gpu:
            world_to_cam_T_b44 = world_to_cam_T_b44.cuda()
            K_b44 = K_b44.cuda()
            self.hom_voxel_coords_14hwd = self.hom_voxel_coords_14hwd.cuda()

        world_to_pix_P_b34 = torch.matmul(K_b44, world_to_cam_T_b44)[:, :3]
        batch_size = world_to_cam_T_b44.shape[0]

        world_points_b4N = \
            self.hom_voxel_coords_14hwd.expand(batch_size, 4, *self.shape).flatten(start_dim=2)
        cam_points_b3N = torch.matmul(world_to_pix_P_b34, world_points_b4N)
        cam_points_b3N[:, :2] = cam_points_b3N[:, :2] / cam_points_b3N[:, 2, None]

        return cam_points_b3N

    def integrate_depth(self, depth_b1hw, world_to_cam_T_b44, K_b44, depth_mask_b1hw = None):

        img_h, img_w = depth_b1hw.shape[2:]
        img_size = torch.tensor([img_w, img_h], dtype=torch.float16).view(1, 1, 1, 2)
        if self.use_gpu:
            depth_b1hw = depth_b1hw.cuda()
            img_size = img_size.cuda()
            self.tsdf.cuda()

        # Project voxel coordinates into images
        cam_points_b3N = self.project_to_camera(world_to_cam_T_b44, K_b44)
        vox_depth_b1N = cam_points_b3N[:, 2:3]
        pixel_coords_b2N = cam_points_b3N[:, :2]

        # Reshape the projected voxel coords to a 2D view of shape Hx(WxD)
        # TODO(clement): see if this can be optimized as one dim is MUCH large than the other one
        pixel_coords_bhw2 = pixel_coords_b2N.view(-1, 2, self.shape[0], self.shape[1] * self.shape[2]).permute(0, 2, 3, 1)
        pixel_coords_bhw2 = 2 * pixel_coords_bhw2 / img_size - 1

        if depth_mask_b1hw is not None:
            depth_b1hw = depth_b1hw.clone()
            depth_b1hw[~depth_mask_b1hw] = -1

        # Sample the depth using grid sample
        # TODO(clement): See if we can avoid using grid_sample
        sampled_depth_b1hw = TF.grid_sample(input=depth_b1hw,
                                            grid=pixel_coords_bhw2,
                                            mode="nearest",
                                            padding_mode="zeros",
                                            align_corners=False)
        sampled_depth_b1N = sampled_depth_b1hw.flatten(start_dim=2)

        # Confidence from InfiniTAM
        confidence_b1N = torch.clamp(
            1.0 - (sampled_depth_b1N - self.min_depth) / (self.max_depth - self.min_depth),
            min=0.0, max=1.0) ** 2

        # Calculate TSDF values from depth difference by normalizing to [-1, 1]
        dist_b1N = sampled_depth_b1N - vox_depth_b1N
        tsdf_vals_b1N = torch.clamp(dist_b1N / self.truncation, min=-1.0, max=1.0)

        # Get the valid points mask
        valid_points_b1N = (vox_depth_b1N > 0) & (dist_b1N > -self.truncation) & \
            (sampled_depth_b1N > 0) & (vox_depth_b1N > 0) & (vox_depth_b1N < self.max_depth) & \
                (confidence_b1N > 0)

        # Updating the TSDF has to be sequential so we break out the batch here
        for tsdf_val_1N, valid_points_1N, confidence_1N in zip(tsdf_vals_b1N,
                                                               valid_points_b1N,
                                                               confidence_b1N):
            # Reshape the valid mask to the TSDF's shape and read the old values
            valid_points_hwd = valid_points_1N.view(self.shape)
            old_tsdf_vals = self.tsdf_values[valid_points_hwd]
            old_weights = self.tsdf_weights[valid_points_hwd]

            # Fetch the new tsdf values and the confidence
            new_tsdf_vals = tsdf_val_1N[valid_points_1N]
            confidence = confidence_1N[valid_points_1N]

            # More infiniTAM magic: update faster when the new samples are more confident
            update_rate = torch.where(confidence < old_weights, 2.0, 5.0).half()

            # Compute the new weight and the normalization factor
            new_weights = confidence * update_rate / self.maxW
            total_weights = old_weights + new_weights

            # Update the tsdf and the weights
            self.tsdf_values[valid_points_hwd] = (old_tsdf_vals * old_weights + new_tsdf_vals * new_weights) / total_weights
            self.tsdf_weights[valid_points_hwd] = torch.clamp(total_weights, max=1.0)
