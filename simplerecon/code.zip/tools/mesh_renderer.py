import os
from black import diff
from pkg_resources import yield_lines
os.environ["PYOPENGL_PLATFORM"] = "egl"
import pyrender
import trimesh
import numpy as np
import torch
import math

from PIL import Image, ImageOps


DEFAULT_MESH_MATERIAL = pyrender.MetallicRoughnessMaterial(
                        metallicFactor=0.5,
                        roughnessFactor=0.8,
                        alphaMode='OPAQUE',
                        baseColorFactor=(.6, .6, .6, 1.))

DEFAULT_CAM_FRUSTUM_MATERIAL = pyrender.MetallicRoughnessMaterial(
                        metallicFactor=0.5,
                        roughnessFactor=0.8,
                        alphaMode='OPAQUE',
                        baseColorFactor=(1.0, 110/255, 0.0, 1.),)
                        # metallicFactor=0.0)


DEFAULT_CAM_DEPTH_MATERIAL = pyrender.MetallicRoughnessMaterial(
                        metallicFactor=0,
                        roughnessFactor=0,
                        alphaMode='OPAQUE',
                        baseColorFactor=(1.0, 1.0, 1.0, 1.))

class Renderer():
    """OpenGL mesh renderer

    Used to render depthmaps from a mesh for 2d evaluation
    """

    def __init__(self, height=480, width=640, flat_render=False):
        self.renderer = pyrender.OffscreenRenderer(width, height)
        # self.scene = pyrender.Scene(ambient_light = [1.0,1.0,1.0,1.0])
        self.scene = pyrender.Scene(ambient_light=0.4)
        self.flat_render = flat_render
        self.render_flags = pyrender.RenderFlags.FLAT

    def render(self, height, width, intrinsics, pose, meshes, lights=None):
        self.renderer.viewport_height = height
        self.renderer.viewport_width = width
        self.scene.clear()
        for mesh in meshes:
            self.scene.add(mesh)

        cam = pyrender.IntrinsicsCamera(cx=intrinsics[0, 2], cy=intrinsics[1, 2],
                                        fx=intrinsics[0, 0], fy=intrinsics[1, 1])
        pose = self.fix_pose(pose)
        self.scene.add(cam, pose=pose)

        # lighting
        
        if lights is not None:
            for light in lights:
                self.scene.add(light[0], pose=light[1])

        if self.flat_render:
            return self.renderer.render(self.scene, self.render_flags)
        else:
            return self.renderer.render(self.scene)

    def __call__(self, height, width, intrinsics, pose, meshes):
        return self.render(height, width, intrinsics, pose, meshes)

    def fix_pose(self, pose):
        # 3D Rotation about the x-axis.
        t = np.pi
        c = np.cos(t)
        s = np.sin(t)
        R = np.array([[1, 0, 0],
                      [0, c, -s],
                      [0, s, c]])
        axis_transform = np.eye(4)
        axis_transform[:3, :3] = R
        return pose @ axis_transform

    def mesh_opengl(self, mesh, mesh_material=None):
        if mesh_material is None:
            return pyrender.Mesh.from_trimesh(mesh)
        else:
            return pyrender.Mesh.from_trimesh(mesh, mesh_material)

    def delete(self):
        self.renderer.delete()

    def render_mesh(self, meshes, height, width, cam_to_world, K, get_colour=False, mesh_materials=None, lights=None):

        try:
            for mesh_ind, mesh in enumerate(meshes):
                if mesh_materials is None:
                    meshes[mesh_ind] = self.mesh_opengl(mesh)
                else:
                    meshes[mesh_ind] = self.mesh_opengl(mesh, mesh_materials[mesh_ind])


            rendered_colour, rendered_depth = self.render(height, width,
                                                          K,
                                                          cam_to_world,
                                                          meshes,
                                                          lights=lights)
            if get_colour:
                return rendered_colour
            else:
                return rendered_depth

        except pyrender.renderer.GLError:
            print('opengl error')
            return None
        
        
def render_colour(renderer, meshes, cam_to_world, K, height=256, width=320):
    colour = renderer.render_mesh(meshes, height, width, cam_to_world, K, get_colour=True)
    if colour is None:
        del renderer
        renderer = Renderer()
        colour = renderer.render_mesh(meshes, height, width, cam_to_world, K, get_colour=True)
        
    return colour

def compute_lookat_vec_and_loc(mean_mesh_location, z_offset = 6, cam_vec_offset=3, current_cam_location=None):
    """ Look at location is the mean of the mesh's vertices. 
        Camera location is then some elevation above this.
    """

    # follow camera
    birdseye_location = mean_mesh_location.copy()
    birdseye_location[2] += z_offset
    mean_to_current_cam = -current_cam_location + mean_mesh_location
    mean_to_current_cam = mean_to_current_cam / np.linalg.norm(mean_to_current_cam)

    birdseye_location[0:2] += cam_vec_offset * mean_to_current_cam[0:2]

    return birdseye_location

def compute_lookat_vec_and_loc_offset(mean_mesh_location, z_offset = 6, x_offset=-2, y_offset=-1, cam_vec_offset=3, current_cam_location=None):
    """ Look at location is the mean of the mesh's vertices. 
        Camera location is then some elevation above this.
    """

    # follow camera
    birdseye_location = mean_mesh_location.copy()
    birdseye_location[2] += z_offset

    birdseye_location[0] += x_offset
    birdseye_location[1] += y_offset

    return birdseye_location


class SmoothBirdsEyeCamera():
    def __init__(self, look_at_moving_alpha = 0.9, mean_mesh_moving_alpha = np.array([0.8,0.8,0.8])):

        self.current_cam_loc = None
        self.current_look_at = None
        self.current_mean_loc = None
        self.fpv_cam_look_at = None

        self.time_steps = 0


        self.look_at_moving_alpha = look_at_moving_alpha
        self.mean_mesh_moving_alpha = mean_mesh_moving_alpha

        return

    def get_bird_eye_loc(self, trimesh_mesh, z_offset = 6, x_offset=3, y_offset=-4, cam_vec_offset=7, fpv_pose=None, reverse_z=False):
        if trimesh_mesh is not None:
            mean_mesh_location = np.array(trimesh_mesh.vertices).mean(0)
            mean_mesh_location += fpv_pose[:3,3] * 5
            mean_mesh_location = mean_mesh_location/6.0
        else:
            mean_mesh_location = fpv_pose[:3,3].copy()


        if self.current_mean_loc is None:
            self.current_mean_loc = mean_mesh_location
        else:
            self.current_mean_loc = self.mean_mesh_moving_alpha * self.current_mean_loc + (1-self.mean_mesh_moving_alpha) * mean_mesh_location

        fpv_cam_transform = np.linalg.inv(fpv_pose)
        z_vec = np.zeros((4,))
        z_vec[2:] = 1
        current_fpv_look_at = fpv_cam_transform @ z_vec

        # print(current_fpv_look_at)
        current_fpv_look_at /=current_fpv_look_at[-1]

        if reverse_z:
            current_fpv_look_at = -current_fpv_look_at

        current_fpv_look_at = -current_fpv_look_at[:3]/np.linalg.norm(current_fpv_look_at[:3])

        if self.fpv_cam_look_at is None:
            self.fpv_cam_look_at = current_fpv_look_at
        else:
            self.fpv_cam_look_at = 0.05*current_fpv_look_at + 0.95*self.fpv_cam_look_at
            # self.fpv_cam_look_at = self.fpv_cam_look_at/np.linalg.norm(self.fpv_cam_look_at)
            self.fpv_cam_look_at = self.fpv_cam_look_at/np.linalg.norm(self.fpv_cam_look_at[:2])
            
        birdseye_location = self.current_mean_loc - self.fpv_cam_look_at * 7
        birdseye_location[2] = self.current_mean_loc[2] + z_offset
        self.current_cam_loc = birdseye_location
        
        self.current_look_at = self.current_mean_loc - self.current_cam_loc
        self.current_look_at = self.current_look_at/np.linalg.norm(self.current_look_at)

        cam_R = np.zeros((3,3))
        cam_t = np.zeros((3,))
        cam_mat = np.identity(4)

        # if self.current_cam_loc is None:
        #     self.current_cam_loc = birdseye_location
        #     self.current_look_at = look_at_vector
        # else:
        #     # self.current_cam_loc = self.loc_moving_alpha * self.current_cam_loc + (1-self.loc_moving_alpha) * birdseye_location
        #     self.current_look_at = self.look_at_moving_alpha * self.current_look_at + (1-self.look_at_moving_alpha) * look_at_vector
        #     self.current_look_at = self.current_look_at / np.linalg.norm(self.current_look_at)

        #     self.current_cam_loc = mean_mesh_location - self.current_look_at * mag

        temp_vec = np.zeros((3,))
        temp_vec[2] = 1

        right_vec = np.cross(self.current_look_at, temp_vec)
        up_vec = np.cross(self.current_look_at, right_vec)

        cam_t = self.current_cam_loc
        cam_R[:,0] = right_vec
        cam_R[:,1] = up_vec
        cam_R[:,2] = self.current_look_at

        cam_mat[:3,:3] = cam_R
        cam_mat[:3,3] = cam_t


        return cam_mat   

    def get_bird_eye_loc_old(self, trimesh_mesh, z_offset = 6, x_offset=3, y_offset=-4, cam_vec_offset=7, current_cam_location=None):
        if trimesh_mesh is not None:
            mean_mesh_location = np.array(trimesh_mesh.vertices).mean(0)
            mean_mesh_location += current_cam_location
            mean_mesh_location = mean_mesh_location/2.0
        else:
            mean_mesh_location = current_cam_location


        if self.current_mean_loc is None:
            self.current_mean_loc = mean_mesh_location
        else:
            self.current_mean_loc = self.mean_mesh_moving_alpha * self.current_mean_loc + (1-self.mean_mesh_moving_alpha) * mean_mesh_location

        birdseye_location = compute_lookat_vec_and_loc_offset(self.current_mean_loc, z_offset, x_offset, y_offset, current_cam_location)

        look_at_vector = (self.current_mean_loc - birdseye_location)
        mag = np.linalg.norm(look_at_vector)
        look_at_vector = look_at_vector / mag

        # print(look_at_vector)

        self.current_look_at = look_at_vector
        self.current_cam_loc = birdseye_location

        cam_R = np.zeros((3,3))
        cam_t = np.zeros((3,))
        cam_mat = np.identity(4)

        # if self.current_cam_loc is None:
        #     self.current_cam_loc = birdseye_location
        #     self.current_look_at = look_at_vector
        # else:
        #     # self.current_cam_loc = self.loc_moving_alpha * self.current_cam_loc + (1-self.loc_moving_alpha) * birdseye_location
        #     self.current_look_at = self.look_at_moving_alpha * self.current_look_at + (1-self.look_at_moving_alpha) * look_at_vector
        #     self.current_look_at = self.current_look_at / np.linalg.norm(self.current_look_at)

        #     self.current_cam_loc = mean_mesh_location - self.current_look_at * mag

        temp_vec = np.zeros((3,))
        temp_vec[2] = 1

        right_vec = np.cross(self.current_look_at, temp_vec)
        up_vec = np.cross(self.current_look_at, right_vec)

        cam_t = self.current_cam_loc
        cam_R[:,0] = right_vec
        cam_R[:,1] = up_vec
        cam_R[:,2] = self.current_look_at

        cam_mat[:3,:3] = cam_R
        cam_mat[:3,3] = cam_t


        return cam_mat            

def camera_marker(camera,
                  marker_height=0.4,
                  rect_width=0.04,
                  sphere_rad=0.08,
                  origin_size=None):
    """
    Create a visual marker for a camera object, including an axis and FOV.

    Parameters
    ---------------
    camera : trimesh.scene.Camera
      Camera object with FOV and transform defined
    marker_height : float
      How far along the camera Z should FOV indicators be
    origin_size : float
      Sphere radius of the origin (default: marker_height / 10.0)

    Returns
    ------------
    meshes : list
      Contains Trimesh and Path3D objects which can be visualized
    """

    # create sane origin size from marker height
    if origin_size is None:
        origin_size = marker_height / 10.0

    # append the visualizations to an array
    meshes = [trimesh.creation.axis(origin_size=origin_size)]

    try:
        # path is a soft dependency
        from trimesh.path.exchange.load import load_path
    except ImportError:
        # they probably don't have shapely installed

        return meshes

    # calculate vertices from camera FOV angles
    x = marker_height * np.tan(np.deg2rad(camera.fov[0]) / 2.0)
    y = marker_height * np.tan(np.deg2rad(camera.fov[1]) / 2.0)
    z = marker_height
    # combine the points into the vertices of an FOV visualization
    points = np.array(
        [(0, 0, 0),
         (-x, -y, z),
         (x, -y, z),
         (x, y, z),
         (-x, y, z)],
        dtype=float)

    # create line segments for the FOV visualization
    # a segment from the origin to each bound of the FOV
    segments = np.column_stack(
        (np.zeros_like(points), points)).reshape(
        (-1, 3))

    mesh_vertices = []
    mesh_faces = []

    #### diagonals

    sphere = trimesh.creation.icosphere(radius=sphere_rad)
    mesh_vertices.append(sphere.vertices)
    mesh_faces.append(sphere.faces)

    max_face_val = sphere.faces.max()

    rect = trimesh.creation.box([rect_width,rect_width,marker_height])
    np_vertices = np.array(rect.vertices)
    np_vertices[:,2] += 0.5 * marker_height
    np_vertices[:,0] = np_vertices[:,0] + np.tan(np.deg2rad(camera.fov[1]) / 2.0) * np_vertices[:,2]
    np_vertices[:,1] = np_vertices[:,1] + np.tan(np.deg2rad(camera.fov[0]) / 2.0) * np_vertices[:,2]
    
    mesh_vertices.append(np_vertices)
    rect.faces += max_face_val+1
    mesh_faces.append(rect.faces)
    
    max_face_val = rect.faces.max()

    rect = trimesh.creation.box([rect_width,rect_width,marker_height])
    np_vertices = np.array(rect.vertices)
    np_vertices[:,2] += 0.5 * marker_height
    np_vertices[:,0] = np_vertices[:,0] + -np.tan(np.deg2rad(camera.fov[1]) / 2.0) * np_vertices[:,2]
    np_vertices[:,1] = np_vertices[:,1] + np.tan(np.deg2rad(camera.fov[0]) / 2.0) * np_vertices[:,2]
    
    mesh_vertices.append(np_vertices)
    rect.faces += max_face_val+1
    mesh_faces.append(rect.faces)
    
    max_face_val = rect.faces.max()

    rect = trimesh.creation.box([rect_width,rect_width,marker_height])
    np_vertices = np.array(rect.vertices)
    np_vertices[:,2] += 0.5 * marker_height
    np_vertices[:,0] = np_vertices[:,0] + -np.tan(np.deg2rad(camera.fov[1]) / 2.0) * np_vertices[:,2]
    np_vertices[:,1] = np_vertices[:,1] + -np.tan(np.deg2rad(camera.fov[0]) / 2.0) * np_vertices[:,2]
    
    mesh_vertices.append(np_vertices)
    rect.faces += max_face_val+1
    mesh_faces.append(rect.faces)

    max_face_val = rect.faces.max()

    rect = trimesh.creation.box([rect_width,rect_width,marker_height])
    np_vertices = np.array(rect.vertices)
    np_vertices[:,2] += 0.5 * marker_height
    np_vertices[:,0] = np_vertices[:,0] + np.tan(np.deg2rad(camera.fov[1]) / 2.0) * np_vertices[:,2]
    np_vertices[:,1] = np_vertices[:,1] + -np.tan(np.deg2rad(camera.fov[0]) / 2.0) * np_vertices[:,2]
    
    mesh_vertices.append(np_vertices)
    rect.faces += max_face_val+1
    mesh_faces.append(rect.faces)
    
    max_face_val = rect.faces.max()

    ### rect at far plane
    rect = trimesh.creation.box([np.tan(np.deg2rad(camera.fov[1]) / 2.0)*2.0*marker_height,rect_width,rect_width])
    np_vertices = np.array(rect.vertices)
    np_vertices[:,2] += marker_height
    np_vertices[:,1] = np_vertices[:,1] + -np.tan(np.deg2rad(camera.fov[0]) / 2.0)*marker_height

    mesh_vertices.append(np_vertices)
    rect.faces += max_face_val+1
    mesh_faces.append(rect.faces)

    max_face_val = rect.faces.max()

    rect = trimesh.creation.box([np.tan(np.deg2rad(camera.fov[1]) / 2.0)*2.0*marker_height,rect_width,rect_width])
    np_vertices = np.array(rect.vertices)
    np_vertices[:,2] += marker_height
    np_vertices[:,1] = np_vertices[:,1] + +np.tan(np.deg2rad(camera.fov[0]) / 2.0)*marker_height

    mesh_vertices.append(np_vertices)
    rect.faces += max_face_val+1
    mesh_faces.append(rect.faces)

    max_face_val = rect.faces.max()

    rect = trimesh.creation.box([rect_width,np.tan(np.deg2rad(camera.fov[0]) / 2.0)*2.0*marker_height,rect_width])
    np_vertices = np.array(rect.vertices)
    np_vertices[:,2] += marker_height
    np_vertices[:,0] = np_vertices[:,0] + -np.tan(np.deg2rad(camera.fov[1]) / 2.0)*marker_height

    mesh_vertices.append(np_vertices)
    rect.faces += max_face_val+1
    mesh_faces.append(rect.faces)

    max_face_val = rect.faces.max()

    rect = trimesh.creation.box([rect_width,np.tan(np.deg2rad(camera.fov[0]) / 2.0)*2.0*marker_height,rect_width])
    np_vertices = np.array(rect.vertices)
    np_vertices[:,2] += marker_height
    np_vertices[:,0] = np_vertices[:,0] + +np.tan(np.deg2rad(camera.fov[1]) / 2.0)*marker_height

    mesh_vertices.append(np_vertices)
    rect.faces += max_face_val+1
    mesh_faces.append(rect.faces)

    max_face_val = rect.faces.max()

    ### assemble final mesh

    vertices = np.concatenate(mesh_vertices, 0)
    faces = np.concatenate(mesh_faces, 0)
    
    frustum = trimesh.Trimesh(vertices=vertices, faces=faces)

    # add a loop for the outside of the FOV then reshape
    # the whole thing into multiple line segments
    segments = np.vstack((segments,
                          points[[1, 2,
                                  2, 3,
                                  3, 4,
                                  4, 1]])).reshape((-1, 2, 3))

    # add a single Path3D object for all line segments
    meshes.append(load_path(segments))

    meshes.append(frustum)

    return meshes

def get_image_box(pil_image, aspect_ratio=4.0/3.0, marker_height=1.0, flip=False):
    from trimesh.visual import texture, TextureVisuals
    
    height = 1.0
    width = height*aspect_ratio
    width*=marker_height
    height*=marker_height

    if flip:
        pil_image = ImageOps.mirror(pil_image)
        width = -width

    vertices = np.zeros((4,3))
    vertices[0,:] = [width/2, height/2, marker_height]
    vertices[1,:] = [width/2, -height/2, marker_height]
    vertices[2,:] = [-width/2, -height/2, marker_height]
    vertices[3,:] = [-width/2, height/2, marker_height]


    faces = np.zeros((2,3))
    faces[0,:] = [0,1,2]
    faces[1,:] = [2,3,0]
    # faces[2,:] = [2,3]
    # faces[3,:] = [3,0]

    uvs = np.zeros((4,2))

    uvs[0,:] = [1.0,0]
    uvs[1,:] = [1.0,1.0]
    uvs[2,:] = [0,1.0]
    uvs[3,:] = [0,0]

    face_normals = np.zeros((2,3))
    face_normals[0,:] = [0.0, 0.0, 1.0]
    face_normals[1,:] = [0.0, 0.0, 1.0]


    material = texture.SimpleMaterial(image=pil_image, ambient=(1.0,1.0,1.0,1.0), diffuse=(1.0,1.0,1.0,1.0))    
    texture = TextureVisuals(uv=uvs, image=pil_image, material=material)

    mesh = trimesh.Trimesh(
                vertices=vertices,
                faces=faces,
                face_normals=face_normals,
                visual=texture,
                validate=True,
                process=False
            )

    return mesh

def create_light_array(light_type, center_loc, x_length=10.0, y_length=10.0, num_x=5, num_y=5):
    lights = []

    # lights.append([light_type, center_loc])


    x_offsets = np.linspace(-x_length, x_length, num_x).squeeze()
    y_offsets = np.linspace(-y_length, y_length, num_y).squeeze()

    X, Y = np.meshgrid(x_offsets, y_offsets)

    coords = np.stack([X,Y], 2).reshape(num_x*num_y,2)

    for coord_ind in range(num_y*num_x):
        x = coords[coord_ind, 0]
        y = coords[coord_ind, 1]
        corner_pos = center_loc.copy()
        corner_pos[2, 0] += x
        corner_pos[2, 1] += y
        lights.append([light_type, corner_pos])

    return lights