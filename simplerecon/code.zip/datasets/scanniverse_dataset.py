import functools
import glob
import json
import os

import kornia
import numpy as np
import PIL.Image as pil
import torch
import torch.nn.functional as F
import torchvision.transforms.functional as TF
from torch.hub import load
from torch.utils.data import Dataset
from torchvision import transforms

from utils.geometry_utils import pose_distance
from utils.generic_utils import (find_color_small_file_paths,
                                 normalize_depth_single, readlines)
import re

from scipy.spatial.transform import Rotation as R

class ScanniverseDataset(Dataset):
    def __init__(self, 
                dataset_path, 
                split,
                mv_split_file_suffix,
                load_full_res_depth=False,
                test_scene_id=None,
                num_images_in_tuple=None,
                color_transform=transforms.ColorJitter(0.2, 0.2, 0.2, 0.2),
                matching_scale=None,
                split_file_location=None,
                image_height=384,
                image_width=512,
                shuffle_tuple=False,
                include_full_depth_K=False,
                use_train_and_val=False,
                load_full_res_color=False,
                pass_frame_id=False,
                skip_frames=None):
        super().__init__()

        self.data_path = dataset_path
        self.scenes_path = dataset_path

        if split_file_location is None:
            split_file_location = dataset_path

        if mv_split_file_suffix is not None:
            split_information_filepath = os.path.join(split_file_location, f"{split}{mv_split_file_suffix}")
        else:
            split_information_filepath = None

        if split_information_filepath is not None:
            self.frame_tuples = readlines(split_information_filepath)

            if test_scene_id is not None:
                self.frame_tuples = [frame_tuple for frame_tuple in self.frame_tuples if test_scene_id in frame_tuple]

            if skip_frames is not None:
                print("####################################################################################################")
                print("####################################################################################################")
                print("####################################################################################################")
                print(f"####################### WARNING: Skipping every {skip_frames} frame! ###############################")
                print("####################################################################################################")
                print("####################################################################################################")
                print("####################################################################################################")
                self.frame_tuples = self.frame_tuples[::skip_frames]
        else: 
            print(f"".center(120, "#"))
            print(f" split_information_filepath doesn't exist. Only basic dataloader functions are available.  ".center(120, "#"))        
            print(f"".center(120, "#"))

        # height, width
        self.image_width = image_width
        self.image_height = image_height
        self.depth_height = self.image_height // 2
        self.depth_width = self.image_width // 2

        self.capture_metadata = {}

        self.pass_frame_id = pass_frame_id

        self.split = split

        self.shuffle_tuple = False

        self.include_full_depth_K = include_full_depth_K

    def __len__(self):
        return len(self.frame_tuples)


    def rotx(self, t):
        ''' 3D Rotation about the x-axis. '''
        c = np.cos(t)
        s = np.sin(t)
        return np.array([[1, 0, 0],
                        [0, c, -s],
                        [0, s, c]])

    @staticmethod
    def get_sub_folder_dir(split):
        return ""
        
    @functools.cache
    def load_pose(self, scene_id, frame_id):
        
        if scene_id not in self.capture_metadata:
            self.load_capture_metadata(scene_id)
        frame_metadata = self.capture_metadata[scene_id][str(frame_id)]

        world_T_cam = torch.eye(4)
        world_T_cam[:3,:3] = torch.tensor(R.from_quat(frame_metadata["extrinsics"]["quadR"]).as_matrix())
        world_T_cam[:3,3] = torch.tensor(frame_metadata["extrinsics"]["T"])
        world_T_cam = world_T_cam

        # gl_to_cv = torch.FloatTensor([[1, -1, -1, 1], [-1, 1, 1, -1], [-1, 1, 1, -1], [1, 1, 1, 1]])
        # world_T_cam *= gl_to_cv
        world_T_cam[1:3, :] = world_T_cam[1:3, :]

        world_T_cam = world_T_cam.numpy()
        
        rot_mat = world_T_cam[:3,:3]
        trans = world_T_cam[:3,3]

        rot_mat = self.rotx(np.pi / 2) @ rot_mat
        trans = self.rotx(np.pi / 2) @ trans

        world_T_cam[:3, :3] = rot_mat
        world_T_cam[:3, 3] = trans
        
        world_T_cam = torch.tensor(world_T_cam)
        cam_T_world = torch.linalg.inv(world_T_cam)

        return world_T_cam, cam_T_world

    def load_intrinsics(self, scene_id, frame_id):

        frame_metadata = self.capture_metadata[scene_id][str(frame_id)]

        f = frame_metadata["intrinsics"]["f"]
        py = frame_metadata["intrinsics"]["py"]
        px = frame_metadata["intrinsics"]["px"]
        int_width = frame_metadata["intrinsics"]["width"]
        int_height = frame_metadata["intrinsics"]["height"]
    
        # image_width = 960
        # image_height = 720
    
        K = torch.eye(4, dtype=torch.float32)
        K[0, 0] = float(f)
        K[1, 1] = float(f)
        K[0, 2] = float(px)
        K[1, 2] = float(py)

        # scale intrinsics to the resized gt depth
        K[0] *= (self.depth_width/int_width) 
        K[1] *= (self.depth_height/int_height)

        # Get the intrinsics of all the scales
        output_dict = {}
        for i in range(5):
            K_scaled = K.clone()
            K_scaled[:2] /= 2 ** i
            invK_scaled = np.linalg.inv(K_scaled)
            output_dict[f"K_s{i}_b44"] = K_scaled
            output_dict[f"invK_s{i}_b44"] = invK_scaled

        if self.include_full_depth_K:   
            K = torch.eye(4, dtype=torch.float32)
            K[0, 0] = float(f)
            K[1, 1] = float(f)
            K[0, 2] = float(px)
            K[1, 2] = float(py)

            K[0] *= (self.depth_width/int_width) 
            K[1] *= (self.depth_height/int_height)

            output_dict[f"K_full_depth_b44"] = K.clone()
            output_dict[f"invK_full_depth_b44"] = torch.tensor(np.linalg.inv(K))

            K[0] *= (640/int_width) 
            K[1] *= (480/int_height)
            output_dict[f"K_480_b44"] = K.clone()
            output_dict[f"invK_480_b44"] = torch.tensor(np.linalg.inv(K))

        return output_dict

    def load_capture_metadata(self, scene_id):
        if scene_id in self.capture_metadata:
            return

        with open(os.path.join(self.data_path, scene_id, "frames.txt")) as f:
            data_lines = f.read()

        frame_index_list = re.finditer("frames \{", data_lines)
        frame_index_list = [loc.start(0) for loc in frame_index_list]

        parent_end_brace_index_list = re.finditer("\n\}", data_lines) # matches new line char
        parent_end_brace_index_list = [loc.start(0) + 1 for loc in parent_end_brace_index_list]

        frame_strings = []
        for frame_info_loc in frame_index_list:
            
            end_brace_loc_ind = list(end_brace_loc > frame_info_loc for end_brace_loc in 
                                    parent_end_brace_index_list).index(True)
            end_brace_loc = parent_end_brace_index_list[end_brace_loc_ind]

            frame_strings.append(data_lines[frame_info_loc:end_brace_loc+1])

            frames = {}

            num_0s = 0
            for frame_ind, frame_string in enumerate(frame_strings):
                frame_lines = frame_string.split("\n")
                frame_info = {}

                frame_info["id"] = 0
                for line_index, line in enumerate(frame_lines):
                    if "id:" in line:
                        frame_info["id"] = line.split(" ")[-1].strip()

                if frame_info["id"] == 0:
                    num_0s+=1

                frame_info["intrinsics"] = {}

                for line_index, line in enumerate(frame_lines):
                    if "camera" in line:
                        frame_info["intrinsics"]["width"] = int(frame_lines[line_index+1].split(" ")[-1].strip())
                        frame_info["intrinsics"]["height"] = int(frame_lines[line_index+2].split(" ")[-1].strip())
                        frame_info["intrinsics"]["f"] = float(frame_lines[line_index+3].split(" ")[-1].strip())
                        frame_info["intrinsics"]["px"] = float(frame_lines[line_index+4].split(" ")[-1].strip())
                        frame_info["intrinsics"]["py"] = float(frame_lines[line_index+5].split(" ")[-1].strip())

                frame_info["extrinsics"] = {}
                for line_index, line in enumerate(frame_lines):
                    if "rotation:" in line:
                        quadR = re.search('\[(.+?)\]', frame_lines[line_index]).group(0)
                        quadR = quadR.replace("[","").replace("]","").split(",")
                        frame_info["extrinsics"]["quadR"] = [float(val) for val in quadR]

                    if "rotation:" in line:
                        t = re.search('\[(.+?)\]', frame_lines[line_index+1]).group(0)
                        t = t.replace("[","").replace("]","").split(",")
                        frame_info["extrinsics"]["T"] = [float(val) for val in t]
                
                frame_info["large_image"] = False
                for line_index, line in enumerate(frame_lines):
                    if "is_large_image:" in line:
                        if "true" in line:
                            frame_info["large_image"] = True

                frames[str(frame_ind)] = frame_info

        self.capture_metadata[scene_id] = frames

    def load_depth(self, depth_filename):
        # depth = torch.from_numpy(np.fromfile(depth_filename, dtype=np.float32).reshape(-1, 256))
        depth = torch.ones(192,256)
        # print(depth.shape)
        # if depth.shape[0] == 192:
        #     depth = depth[24:-24]
        return depth.unsqueeze(0)

    def load_confidence(self, confidence_filename):
        # conf = torch.from_numpy(np.fromfile(confidence_filename, dtype=np.uint8).reshape(-1, 256))
        conf = torch.ones(192,256)
        # if conf.shape[0] == 192:
        #     conf = conf[24:-24]
        return conf.unsqueeze(0)

    def load_color(self, scene_id, frame_id):

        color_filename = os.path.join(self.data_path, scene_id, "imgl", f"{frame_id:05d}.jpg")
        
        if not os.path.exists(color_filename):
            color_filename = os.path.join(self.data_path, scene_id, "img", f"{frame_id:05d}.jpg")

        image = pil.open(color_filename)
        # conf = TF.to_tensor(pil.open(color_filename).resize(self.color_shape[::-1]))
        
        img_width = image.size[0]
        # target_height = 288 if img_width == 960 else 384
        target_height = 384
        image = TF.to_tensor(image.resize((512, target_height)))
        # if target_height == 384:
        #     image = image[:, 48:-48]
        return image


    def get_frame(self, scene_id, frame_id, load_depth):

        self.load_capture_metadata(scene_id)

        # color_filename = os.path.join(self.data_path, scene_id, f"frame_{frame_id:010d}.jpg")
        image = self.load_color(scene_id, frame_id)

        # Augment
        if self.split == "train":
            image = self.color_transform(image)

        image = TF.normalize(image, (0.485, 0.456, 0.406), (0.229, 0.224, 0.225))

        intrinsics = self.load_intrinsics(scene_id, frame_id)

        world_T_cam, cam_T_world = self.load_pose(scene_id, frame_id)


        if load_depth:

            # Load depth, resize to half res of image and crop 8pix on each side
            depth_filename = os.path.join(self.data_path, scene_id, f"depth_{frame_id}.bin")
            depth = self.load_depth(depth_filename)

            conf_filename = os.path.join(self.data_path, scene_id, f"depthConfidence_{frame_id}.bin")
            conf = self.load_confidence(conf_filename)

            # Get the float valid mask
            mask_b = conf != 0
            mask = mask_b.float()

            depth[~mask_b] = torch.tensor(np.nan)


        else:

            depth = torch.zeros((1, 1, 1), dtype=torch.float32)
            mask = torch.zeros((1, 1, 1), dtype=torch.float32)
            mask_b = torch.zeros((1, 1, 1), dtype=torch.bool)

        output_dict = {
            "image_b3hw": image,
            "depth_b1hw": depth,
            "full_res_color_b3hw": image,
            "full_res_depth_b1hw": depth,
            "mask_b1hw": mask,
            "mask_b_b1hw": mask_b,
            "world_T_cam_b44": world_T_cam,
            "cam_T_world_b44": cam_T_world,
            }
        
        output_dict.update(intrinsics)

        if self.pass_frame_id:
            output_dict["frame_id"] = frame_id

        return output_dict


    def stack_ref_data(self, ref_data):

        tensor_names = ref_data[0].keys()

        stacked_ref_data = {}
        for tensor_name in tensor_names:
            stacked_ref_data[tensor_name] = torch.tensor(np.stack([t[tensor_name] for t in ref_data], axis=0))

        return stacked_ref_data

    def __getitem__(self, idx):

        scene_id, *frame_ids = self.frame_tuples[idx].split(" ")
        frame_ids = [int(f) for f in frame_ids]

        inputs = []
        for i, frame_id in enumerate(frame_ids):
            inputs += [self.get_frame(scene_id, frame_id, load_depth=True)]

        cur_data, *ref_data_list = inputs
        ref_data = self.stack_ref_data(ref_data_list)

        valid_depth = cur_data["depth_b1hw"][cur_data["mask_b_b1hw"]]

        cur_data["min_depth"] = valid_depth.min().view(1, 1, 1)
        cur_data["max_depth"] = valid_depth.max().view(1, 1, 1)

        if not self.shuffle_tuple:
            # order reference images based on posea penalty 
            ref_world_T_cam = torch.tensor(ref_data["world_T_cam_b44"])
            cur_cam_T_world = torch.tensor(cur_data["cam_T_world_b44"])

            # Compute cur_cam_T_ref_cam
            cur_cam_T_ref_cam = cur_cam_T_world.unsqueeze(0) @ ref_world_T_cam

            frame_penalty_k, _, _ = pose_distance(cur_cam_T_ref_cam)

            indices = torch.argsort(frame_penalty_k).tolist()
            ref_data_list = [ref_data_list[index] for index in indices]

            ref_data = self.stack_ref_data(ref_data_list)

        return cur_data, ref_data

