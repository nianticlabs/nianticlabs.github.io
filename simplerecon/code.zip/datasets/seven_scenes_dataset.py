import glob
import logging
import os
import random

import kornia
import numpy as np
import PIL.Image as pil
import torch
import torch.nn.functional as F
import torchvision.transforms.functional as TF
from torch.hub import load
from torch.utils.data import Dataset
from torchvision import transforms

from utils.generic_utils import (find_color_small_file_paths,
                                 normalize_depth_single, readlines)
from utils.geometry_utils import pose_distance

logger = logging.getLogger(__name__)

class SevenScenesDataset(Dataset):
    def __init__(self,
                 dataset_path,
                 split,
                 mv_split_file_suffix,
                 load_full_res_depth=False,
                 test_scene_id=None,
                 num_images_in_tuple=None,
                 color_transform=transforms.ColorJitter(0.2, 0.2, 0.2, 0.2),
                 matching_scale=None,
                 split_file_location=None,
                 image_height=384,
                 image_width=512,
                 input_image_size=512,
                 input_depth_size=256,
                 shuffle_tuple=False,
                 include_full_depth_K=False,
                 use_train_and_val=False,
                 load_full_res_color=False,
                 pass_frame_id=False,
                 skip_frames=None):
        super(SevenScenesDataset).__init__()


        self.split = split
        self.matching_scale = matching_scale

        if mv_split_file_suffix is not None:
            split_information_filepath = os.path.join(split_file_location, f"{split}{mv_split_file_suffix}")
        else:
            split_information_filepath = None

        if split_information_filepath is not None:
            if use_train_and_val:
                print("####################################################################################################")
                print("####################################################################################################")
                print("####################################################################################################")
                print("######################### WARNING: Training on train and val sets! #################################")
                print("####################################################################################################")
                print("####################################################################################################")
                print("####################################################################################################")
                split_information_filepath = os.path.join(split_file_location, f"all_data{mv_split_file_suffix}")
            else:
                split_information_filepath = os.path.join(split_file_location, f"{split}{mv_split_file_suffix}")

            self.frame_tuples = readlines(split_information_filepath)

            if test_scene_id is not None:
                self.frame_tuples = [frame_tuple for frame_tuple in self.frame_tuples if test_scene_id in frame_tuple]

            if split == "test":
                frame_ids = [int(frame_tuple.split(" ")[1]) for frame_tuple in self.frame_tuples]
                self.frame_tuples = [self.frame_tuples[i] for i in np.argsort(frame_ids).tolist()]

            self.skip_frames = skip_frames

            if skip_frames is not None:
                print("####################################################################################################")
                print("####################################################################################################")
                print("####################################################################################################")
                print(f"####################### WARNING: Skipping every {skip_frames} frame! ###############################")
                print("####################################################################################################")
                print("####################################################################################################")
                print("####################################################################################################")
                self.frame_tuples = self.frame_tuples[::skip_frames]
        else: 
            print(f"".center(120, "#"))
            print(f" split_information_filepath doesn't exist. Only basic dataloader functions are available.  ".center(120, "#"))        
            print(f"".center(120, "#"))

        self.scenes_path = os.path.join(dataset_path)

        self.crop_edges = False

        self.color_transform = color_transform
        self.shuffle_tuple = shuffle_tuple

        self.load_full_res_depth = load_full_res_depth
        self.num_images_in_tuple = num_images_in_tuple

        self.image_width = image_width
        self.image_height = image_height
        self.depth_height = self.image_height // 2
        self.depth_width = self.image_width // 2
        self.input_image_size = input_image_size
        self.input_depth_size = input_depth_size

        self.include_full_depth_K = include_full_depth_K
        self.load_full_res_color = load_full_res_color

        
    def __len__(self):
        return len(self.frame_tuples)

    @staticmethod
    def get_sub_folder_dir(split):
        return ""

    def load_intrinsics(self, scene_id=None, frame_id=None):

        K = torch.eye(4, dtype=torch.float32)
        K[0, 0] = float(525)
        K[1, 1] = float(525)
        K[0, 2] = float(320)
        K[1, 2] = float(240)

        # scale intrinsics to the resized gt depth
        K[0] *= self.depth_width / 640
        K[1] *= self.depth_height / 480

        # Get the intrinsics of all the scales
        output_dict = {}
        for i in range(5):
            K_scaled = K.clone()
            K_scaled[:2] /= 2 ** i
            invK_scaled = np.linalg.inv(K_scaled)
            output_dict[f"K_s{i}_b44"] = K_scaled
            output_dict[f"invK_s{i}_b44"] = invK_scaled

        if self.include_full_depth_K:
            K = torch.eye(4, dtype=torch.float32)
            K[0, 0] = float(525)
            K[1, 1] = float(525)
            K[0, 2] = float(320)
            K[1, 2] = float(240)

            output_dict[f"K_full_depth_b44"] = K.clone()
            output_dict[f"invK_full_depth_b44"] = np.linalg.inv(K)


        return output_dict

    def read_image_file(self, filename, height=None, width=None, value_scale_factor=1.0, resampling_mode=pil.BILINEAR):
        img = pil.open(filename)
        # if crop:
        #     img = img.crop([25,19,640-25,480-19]).resize((640, 480))
        # im1 = im.crop((left, top, right, bottom))
        if height is not None and width is not None:
            img_width, img_height = img.size
            if (img_width, img_height) != (width, height):
                if width > img_width or height > img_height:
                    logger.warning(
                        f"WARNING: target size ({width}, {height}) has a dimension larger than input size "
                        f"({img_width}, {img_height}). While this will work, it will be very slow and you're losing"
                        f"detail anyway.")
                img = img.resize((width, height), resample=resampling_mode)
        depth = TF.to_tensor(img).float() * value_scale_factor
        return depth

    def load_depth_and_mask(self, depth_filename, load_depth):

        if load_depth:

            # Load depth, resize to half res of image
            depth = self.read_image_file(depth_filename,
                                         height=self.depth_height,
                                         width=self.depth_width,
                                         value_scale_factor=1e-3,
                                         resampling_mode=pil.NEAREST)

            # Get the float valid mask
            mask_b = (depth > 1e-3) & (depth < 10)
            mask = mask_b.float()

            depth[~mask_b] = torch.tensor(np.nan)

        else:

            depth = torch.zeros((1, 1, 1), dtype=torch.float32)
            mask = torch.zeros((1, 1, 1), dtype=torch.float32)
            mask_b = torch.zeros((1, 1, 1), dtype=torch.bool)

        return depth, mask, mask_b

    def load_full_res_depth_and_mask(self, full_res_depth_filename):

        if self.load_full_res_depth:

            full_res_depth = self.read_image_file(full_res_depth_filename, value_scale_factor=1e-3)

            # Get the float valid mask
            full_res_mask_b = (full_res_depth > 1e-3) & (full_res_depth < 10)
            full_res_mask = full_res_mask_b.float()

            full_res_depth[~full_res_mask_b] = torch.tensor(np.nan)

        else:
            full_res_depth = torch.zeros((1, 1, 1), dtype=torch.float32)
            full_res_mask = torch.zeros((1, 1, 1), dtype=torch.float32)
            full_res_mask_b = torch.zeros((1, 1, 1), dtype=torch.bool)

        return full_res_depth, full_res_mask, full_res_mask_b

    def load_pose(self, scene_id, frame_id):

        scene_path = os.path.join(self.scenes_path, scene_id)
        sensor_data_dir = os.path.join(scene_path, "sensor_data")

        pose_path = os.path.join(sensor_data_dir, f"frame-{frame_id:06d}.pose.txt")

        world_T_cam = np.genfromtxt(pose_path).astype(np.float32)
        cam_T_world = np.linalg.inv(world_T_cam)
        
        return world_T_cam, cam_T_world

    def get_frame(self, scene_id, frame_id, load_depth):

        output_dict = {}

        scene_path = os.path.join(self.scenes_path, scene_id)
        sensor_data_dir = os.path.join(scene_path)

        color_filename = os.path.join(sensor_data_dir, f"frame-{frame_id:06d}.color.png")
        depth_filename = color_filename.replace(f"color", f"depth.proj")


        intrinsics = self.load_intrinsics(scene_id, frame_id)
        world_T_cam, cam_T_world = self.load_pose(scene_id, frame_id)

        # Load image
        image = self.read_image_file(color_filename, height=self.image_height, width=self.image_width)

        if self.load_full_res_color:
            color_full_res_filename = os.path.join(sensor_data_dir, f"frame-{frame_id:06d}.color.png")
            full_res_color = self.read_image_file(color_full_res_filename, height=480, width=640)
            full_res_color = TF.normalize(full_res_color, (0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
        else:
            full_res_color = torch.zeros((1, 1, 1), dtype=torch.float32)

        # Augment
        if self.split == "train":
            image = self.color_transform(image)

        # Do imagenet normalization
        image = TF.normalize(image, (0.485, 0.456, 0.406), (0.229, 0.224, 0.225))

        depth, mask, mask_b = self.load_depth_and_mask(depth_filename, load_depth)

        full_res_depth_filename = color_filename.replace(f"color", "depth.proj")
        full_res_depth, full_res_mask, full_res_mask_b = self.load_full_res_depth_and_mask(full_res_depth_filename)

        output_dict = {
            "image_b3hw": image,
            "depth_b1hw": depth,
            "mask_b1hw": mask,
            "mask_b_b1hw": mask_b,
            "full_res_depth_b1hw": full_res_depth,
            "full_res_mask_b1hw": full_res_mask,
            "full_res_mask_b_b1hw": full_res_mask_b,
            "world_T_cam_b44": world_T_cam,
            "cam_T_world_b44": cam_T_world,
            "full_res_color_b3hw": full_res_color,
            }
        output_dict.update(intrinsics)

        return output_dict

    def stack_ref_data(self, ref_data):

        tensor_names = ref_data[0].keys()

        stacked_ref_data = {}
        for tensor_name in tensor_names:
            stacked_ref_data[tensor_name] = np.stack([t[tensor_name] for t in ref_data], axis=0)

        return stacked_ref_data

    def __getitem__(self, idx):

        scene_id, *frame_ids = self.frame_tuples[idx].split(" ")
        frame_ids = [int(f) for f in frame_ids]


        if self.shuffle_tuple:
            first_frame_id = frame_ids[0]
            shuffled_list = frame_ids[1:]
            random.shuffle(shuffled_list)
            frame_ids = [first_frame_id] + shuffled_list

        if self.num_images_in_tuple is not None:
            frame_ids = frame_ids[:self.num_images_in_tuple]

        inputs = []
        for i, frame_id in enumerate(frame_ids):
            inputs += [self.get_frame(scene_id, frame_id, load_depth=True)]

        cur_data, *ref_data_list = inputs
        ref_data = self.stack_ref_data(ref_data_list)

        valid_depth = cur_data["depth_b1hw"][cur_data["mask_b_b1hw"]]

        cur_data["min_depth"] = valid_depth.min().view(1, 1, 1)
        cur_data["max_depth"] = valid_depth.max().view(1, 1, 1)

        if not self.shuffle_tuple:
            # order reference images based on posea penalty
            ref_world_T_cam = torch.tensor(ref_data["world_T_cam_b44"])
            cur_cam_T_world = torch.tensor(cur_data["cam_T_world_b44"])

            # Compute cur_cam_T_ref_cam
            cur_cam_T_ref_cam = cur_cam_T_world.unsqueeze(0) @ ref_world_T_cam

            frame_penalty_k, _, _ = pose_distance(cur_cam_T_ref_cam)

            indices = torch.argsort(frame_penalty_k).tolist()
            ref_data_list = [ref_data_list[index] for index in indices]

            ref_data = self.stack_ref_data(ref_data_list)

        return cur_data, ref_data
