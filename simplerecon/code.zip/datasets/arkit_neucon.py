import functools
import glob
import json
import os

from tqdm import tqdm
import kornia
import numpy as np
import PIL.Image as pil
import torch
import torch.nn.functional as F
import torchvision.transforms.functional as TF
from torch.hub import load
from torch.utils.data import Dataset
from torchvision import transforms

from utils.geometry_utils import pose_distance
from utils.generic_utils import (find_color_small_file_paths,
                                 normalize_depth_single, readlines)


class ARKitDataset(Dataset):
    def __init__(self,
                 dataset_path,
                 split,
                 mv_split_file_suffix,
                 load_full_res_depth=False,
                 test_scene_id=None,
                 num_images_in_tuple=None,
                 color_transform=transforms.ColorJitter(0.2, 0.2, 0.2, 0.2),
                 matching_scale=None,
                 split_file_location=None,
                 image_height=384,
                 image_width=512,
                 input_image_size=512,
                 input_depth_size=480,
                 shuffle_tuple=False,
                 include_full_depth_K=False,
                 use_train_and_val=False,
                 load_full_res_color=False,
                 pass_frame_id=False,
                 skip_frames=None):
        super(ARKitDataset).__init__()


        self.split = split
        self.matching_scale = matching_scale

        if mv_split_file_suffix is not None:
            split_information_filepath = os.path.join(split_file_location, f"{split}{mv_split_file_suffix}")
        else:
            split_information_filepath = None

        if split_information_filepath is not None:
            
            self.frame_tuples = readlines(split_information_filepath)

            print(split_information_filepath)

            if test_scene_id is not None:
                self.frame_tuples = [frame_tuple for frame_tuple in self.frame_tuples if test_scene_id in frame_tuple]

            if split == "test":
                frame_ids = [int(frame_tuple.split(" ")[1]) for frame_tuple in self.frame_tuples]
                self.frame_tuples = [self.frame_tuples[i] for i in np.argsort(frame_ids).tolist()]

            self.skip_frames = skip_frames

            if skip_frames is not None:
                print(f"".center(80, "#"))
                print(f"".center(80, "#"))
                print(f"".center(80, "#"))
                print(f" WARNING: Skipping every {skip_frames} frame! ".center(80, "#"))
                print(f"".center(80, "#"))
                print(f"".center(80, "#"))
                print(f"".center(80, "#"))
                print("")
                self.frame_tuples = self.frame_tuples[::skip_frames]
        else: 
            print(f"".center(120, "#"))
            print(f" split_information_filepath doesn't exist. Only basic dataloader functions are available.  ".center(120, "#"))        
            print(f"".center(120, "#"))

        self.scenes_path = os.path.join(dataset_path, ARKitDataset.get_sub_folder_dir(split))

        self.crop_edges = False

        self.color_transform = color_transform
        self.shuffle_tuple = shuffle_tuple

        self.load_full_res_depth = load_full_res_depth
        self.num_images_in_tuple = num_images_in_tuple

        self.image_width = image_width
        self.image_height = image_height
        self.depth_height = image_height // 2
        self.depth_width = image_width // 2
        self.input_image_size = input_image_size
        self.input_depth_size = input_depth_size

        self.include_full_depth_K = include_full_depth_K
        self.load_full_res_color = load_full_res_color


        self.pass_frame_id = pass_frame_id

        
    def __len__(self):
        return len(self.frame_tuples)

    @staticmethod
    def get_sub_folder_dir(split):
        return "scans"

    def get_intrinsics(self, scene_id, frame_id):

        intrinsics_path = os.path.join(self.scenes_path, scene_id, "intrinsics")
        intrinsics_filename = os.path.join(intrinsics_path, f"{frame_id:05d}.txt")

        # intrinsics already scaled at preprocess
        K = torch.eye(4, dtype=torch.float32)
        K[0:3, 0:3] = torch.tensor(np.genfromtxt(intrinsics_filename).astype(np.float32))

        K[0] *= self.depth_width / 640
        K[1] *= self.depth_height / 480

        # Get the intrinsics of all the scales
        output_dict = {}
        for i in range(5):
            K_scaled = K.clone()
            K_scaled[:2] /= 2 ** i
            invK_scaled = np.linalg.inv(K_scaled)
            output_dict[f"K_s{i}_b44"] = K_scaled
            output_dict[f"invK_s{i}_b44"] = invK_scaled

        if self.include_full_depth_K:   
            K = torch.eye(4, dtype=torch.float32)
            K[0:3, 0:3] = torch.tensor(np.genfromtxt(intrinsics_filename).astype(np.float32))
            output_dict[f"K_full_depth_b44"] = K.clone()
            output_dict[f"invK_full_depth_b44"] = torch.tensor(np.linalg.inv(K))

        return output_dict

    def load_pose(self, scene_id, frame_id):
        poses_path = os.path.join(self.scenes_path, scene_id, "poses")
        pose_filename = os.path.join(poses_path, f"{frame_id:05d}.txt")

        world_T_cam = np.genfromtxt(pose_filename).astype(np.float32)
        cam_T_world = np.linalg.inv(world_T_cam)
        return world_T_cam, cam_T_world


    def read_image_file(self, filename, height=None, width=None, value_scale_factor=1.0, resampling_mode=pil.BILINEAR):
        img = pil.open(filename)
        # if crop:
        #     img = img.crop([25,19,640-25,480-19]).resize((640, 480))
        # im1 = im.crop((left, top, right, bottom))
        if height is not None and width is not None:
            img_width, img_height = img.size
            if (img_width, img_height) != (width, height):
                if width > img_width or height > img_height:
                    logger.warning(
                        f"WARNING: target size ({width}, {height}) has a dimension larger than input size "
                        f"({img_width}, {img_height}). While this will work, it will be very slow and you're losing"
                        f"detail anyway.")
                img = img.resize((width, height), resample=resampling_mode)
        depth = TF.to_tensor(img).float() * value_scale_factor
        return depth

    def load_depth_and_mask(self, depth_filename, load_depth):

        if load_depth:

            # Load depth, resize to half res of image
            depth = self.read_image_file(depth_filename,
                                         height=self.depth_height,
                                         width=self.depth_width,
                                         value_scale_factor=1e-3,
                                         resampling_mode=pil.NEAREST)

            # Get the float valid mask
            mask_b = (depth > 1e-3) & (depth < 10)
            mask = mask_b.float()

            depth[~mask_b] = torch.tensor(np.nan)

        else:

            depth = torch.ones((1, 480, 640), dtype=torch.float32)
            mask = torch.ones((1, 480, 640), dtype=torch.float32)
            mask_b = torch.ones((1, 480, 640), dtype=torch.bool)

        return depth, mask, mask_b



    def get_frame(self, scene_id, frame_id, load_depth):

        output_dict = {}

        color_path = os.path.join(self.scenes_path, scene_id, "images")
        color_filename = os.path.join(color_path, f"{frame_id:05d}.png")

        intrinsics = self.get_intrinsics(scene_id, frame_id)

        world_T_cam, cam_T_world = self.load_pose(scene_id, frame_id)

        # Load image
        image = self.read_image_file(color_filename, height=self.image_height, width=self.image_width)

        # Augment
        if self.split == "train":
            image = self.color_transform(image)

        # Do imagenet normalization
        image = TF.normalize(image, (0.485, 0.456, 0.406), (0.229, 0.224, 0.225))

        full_res_color = image.clone()

        depth, mask, mask_b = self.load_depth_and_mask(depth_filename = None, load_depth = False)

        full_res_depth, full_res_mask, full_res_mask_b = depth, mask, mask_b

        output_dict = {
            "image_b3hw": image,
            "depth_b1hw": depth,
            "mask_b1hw": mask,
            "mask_b_b1hw": mask_b,
            "full_res_depth_b1hw": full_res_depth,
            "full_res_mask_b1hw": full_res_mask,
            "full_res_mask_b_b1hw": full_res_mask_b,
            "world_T_cam_b44": world_T_cam,
            "cam_T_world_b44": cam_T_world,
            "full_res_color_b3hw": full_res_color,
            }
        output_dict.update(intrinsics)

        if self.pass_frame_id:
            output_dict["frame_id"] = frame_id
            
        return output_dict

    def stack_ref_data(self, ref_data):

        tensor_names = ref_data[0].keys()

        stacked_ref_data = {}
        for tensor_name in tensor_names:
            stacked_ref_data[tensor_name] = np.stack([t[tensor_name] for t in ref_data], axis=0)

        return stacked_ref_data

    def __getitem__(self, idx):

        scene_id, *frame_ids = self.frame_tuples[idx].split(" ")
        frame_ids = [int(f) for f in frame_ids]


        if self.shuffle_tuple:
            first_frame_id = frame_ids[0]
            shuffled_list = frame_ids[1:]
            random.shuffle(shuffled_list)
            frame_ids = [first_frame_id] + shuffled_list

        if self.num_images_in_tuple is not None:
            frame_ids = frame_ids[:self.num_images_in_tuple]

        inputs = []
        for i, frame_id in enumerate(frame_ids):
            inputs += [self.get_frame(scene_id, frame_id, load_depth=True)]

        cur_data, *ref_data_list = inputs
        ref_data = self.stack_ref_data(ref_data_list)

        valid_depth = cur_data["depth_b1hw"][cur_data["mask_b_b1hw"]]

        cur_data["min_depth"] = valid_depth.min().view(1, 1, 1)
        cur_data["max_depth"] = valid_depth.max().view(1, 1, 1)

        if not self.shuffle_tuple:
            # order reference images based on posea penalty
            ref_world_T_cam = torch.tensor(ref_data["world_T_cam_b44"])
            cur_cam_T_world = torch.tensor(cur_data["cam_T_world_b44"])

            # Compute cur_cam_T_ref_cam
            cur_cam_T_ref_cam = cur_cam_T_world.unsqueeze(0) @ ref_world_T_cam

            frame_penalty_k, _, _ = pose_distance(cur_cam_T_ref_cam)

            indices = torch.argsort(frame_penalty_k).tolist()
            ref_data_list = [ref_data_list[index] for index in indices]

            ref_data = self.stack_ref_data(ref_data_list)

        return cur_data, ref_data

def process_data(data_path, data_source='ARKit', ori_size=(1920, 1440), size=(640, 480)):
    # save image
    print('Extract images from video...')
    video_path = os.path.join(data_path, 'Frames.m4v')
    image_path = os.path.join(data_path, 'images')
    if not os.path.exists(image_path):
        os.mkdir(image_path)
    extract_frames(video_path, out_folder=image_path, size=size)

    # load intrin and extrin
    print('Load intrinsics and extrinsics')
    sync_intrinsics_and_poses(os.path.join(data_path, 'Frames.txt'), os.path.join(data_path, 'ARposes.txt'),
                            os.path.join(data_path, 'SyncedPoses.txt'))

    path_dict = path_parser(data_path, data_source=data_source)
    cam_intrinsic_dict = load_camera_intrinsic(
        path_dict['cam_intrinsic'], data_source=data_source)

    for k, v in tqdm(cam_intrinsic_dict.items(), desc='Processing camera intrinsics...'):
        cam_intrinsic_dict[k]['K'][0, :] /= (ori_size[0] / size[0])
        cam_intrinsic_dict[k]['K'][1, :] /= (ori_size[1] / size[1])
    cam_pose_dict = load_camera_pose(
        path_dict['camera_pose'], data_source=data_source)

    # save_intrinsics_extrinsics
    if not os.path.exists(os.path.join(data_path, 'poses')):
        os.mkdir(os.path.join(data_path, 'poses'))
    for k, v in tqdm(cam_pose_dict.items(), desc='Saving camera extrinsics...'):
        np.savetxt(os.path.join(data_path, 'poses', '{}.txt'.format(k)), v, delimiter=' ')

    if not os.path.exists(os.path.join(data_path, 'intrinsics')):
        os.mkdir(os.path.join(data_path, 'intrinsics'))
    for k, v in tqdm(cam_intrinsic_dict.items(), desc='Saving camera intrinsics...'):
        np.savetxt(os.path.join(data_path, 'intrinsics', '{}.txt'.format(k)), v['K'], delimiter=' ')

def path_parser(root_path, data_source='TagBA'):
    full_path = root_path
    path_dict = dict()
    if data_source == 'TagBA':
        path_dict['camera_pose'] = os.path.join(
            full_path, 'TagBA', 'CameraTrajectory-BA.txt')
        path_dict['cam_intrinsic'] = os.path.join(
            full_path, 'camera_intrinsics.json')
    elif data_source == 'ARKit':
        path_dict['camera_pose'] = os.path.join(full_path, 'SyncedPoses.txt')
        path_dict['cam_intrinsic'] = os.path.join(full_path, 'Frames.txt')
    elif data_source == 'SenseAR':
        path_dict['camera_pose'] = os.path.join(full_path, 'frame_pose.csv')
        path_dict['cam_intrinsic'] = os.path.join(
            full_path, 'device_parameter.txt')
    return path_dict


def rotx(t):
    ''' 3D Rotation about the x-axis. '''
    c = np.cos(t)
    s = np.sin(t)
    return np.array([[1, 0, 0],
                     [0, c, -s],
                     [0, s, c]])


def load_camera_pose(cam_pose_dir, use_homogenous=True, data_source='TagBA'):
    if cam_pose_dir is not None and os.path.isfile(cam_pose_dir):
        pass
    else:
        raise FileNotFoundError("Given camera pose dir:{} not found"
                                .format(cam_pose_dir))

    from transforms3d.quaternions import quat2mat

    pose_dict = dict()

    def process(line_data_list):
        line_data = np.array(line_data_list, dtype=float)
        fid = line_data_list[0]
        trans = line_data[1:4]
        quat = line_data[4:]
        rot_mat = quat2mat(np.append(quat[-1], quat[:3]).tolist())
        if data_source == 'ARKit':
            rot_mat = rot_mat.dot(np.array([
                [1, 0, 0],
                [0, -1, 0],
                [0, 0, -1]
            ]))
            rot_mat = rotx(np.pi / 2) @ rot_mat
            trans = rotx(np.pi / 2) @ trans
        trans_mat = np.zeros([3, 4])
        trans_mat[:3, :3] = rot_mat
        trans_mat[:3, 3] = trans
        if use_homogenous:
            trans_mat = np.vstack((trans_mat, [0, 0, 0, 1]))
        pose_dict[fid] = trans_mat

    print(f"data source: {data_source}")
    if data_source == 'TagBA' or data_source == 'ARKit':
        with open(cam_pose_dir, "r") as f:
            cam_pose_lines = f.readlines()
        for cam_line in cam_pose_lines:
            line_data_list = cam_line.split(" ")
            if len(line_data_list) == 0:
                continue
            process(line_data_list)
    elif data_source == 'SenseAR':
        import csv
        with open(cam_pose_dir, 'r') as f:
            reader = csv.reader(f, delimiter=' ', quotechar='|')
            for line_data_list in reader:
                if len(line_data_list) is not 8:
                    continue
                process(line_data_list)

    return pose_dict


def load_camera_intrinsic(cam_file, data_source='TagBA'):
    """Load camera parameter from file"""
    assert os.path.isfile(
        cam_file), "camera info:{} not found".format(cam_file)

    cam_dict = dict()
    if data_source == 'TagBA':
        with open(cam_file, "r") as f:
            cam_info = json.load(f)
        cam_dict['K'] = np.array([
            [cam_info['fx'], 0, cam_info['cx']],
            [0, cam_info['fy'], cam_info['cy']],
            [0, 0, 1]
        ], dtype=float)
        w = int(cam_info['horizontal_resolution'])
        h = int(cam_info['vertical_resolution'])
        cam_dict['shape'] = (w, h)
        cam_dict['dist_coeff'] = np.array(
            cam_info['distortion_coefficients'], dtype=float)
    elif data_source == 'Open3D':
        with open(cam_file, "r") as f:
            cam_info = json.load(f)
        cam_dict['K'] = np.array(
            cam_info['intrinsic_matrix'], dtype=float).reshape(3, 3).transpose()
        w = int(cam_info['width'])
        h = int(cam_info['height'])
        cam_dict['shape'] = (w, h)
        cam_dict['dist_coeff'] = np.array([0.0, 0.0, 0.0, 0.0, 0.0])
    elif data_source == 'SenseAR':
        with open(cam_file, 'r') as f:
            cam_lines = f.readlines()
            cam_dict['K'] = np.array([
                [float(cam_lines[2].split(': ')[1]), 0, float(cam_lines[4].split(': ')[1])],
                [0, float(cam_lines[3].split(': ')[1]), float(cam_lines[5].split(': ')[1])],
                [0, 0, 1]
            ], dtype=float)
    elif data_source == 'ARKit':
        with open(cam_file, "r") as f:
            cam_intrinsic_lines = f.readlines()

        cam_intrinsic_dict = dict()
        for line in cam_intrinsic_lines:
            line_data_list = [float(i) for i in line.split(',')]
            if len(line_data_list) == 0:
                continue
            cam_dict = dict()
            cam_dict['K'] = np.array([
                [line_data_list[2], 0, line_data_list[4]],
                [0, line_data_list[3], line_data_list[5]],
                [0, 0, 1]
            ], dtype=float)
            cam_intrinsic_dict[str(int(line_data_list[1])).zfill(5)] = cam_dict
        return cam_intrinsic_dict
    else:
        raise NotImplementedError(
            "Data parsing for source: {} not implemented".format(data_source))

    return cam_dict


def extract_frames(video_path, out_folder, size):
    import cv2
    cap = cv2.VideoCapture(video_path)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    for i in tqdm(range(frame_count)):
        ret, frame = cap.read()
        if ret is not True:
            break
        frame = cv2.resize(frame, size)
        cv2.imwrite(os.path.join(out_folder, str(i).zfill(5) + '.png'), frame)



def sync_intrinsics_and_poses(cam_file, pose_file, out_file):
    """Load camera intrinsics"""
    assert os.path.isfile(cam_file), "camera info:{} not found".format(cam_file)
    with open(cam_file, "r") as f:
        cam_intrinsic_lines = f.readlines()
    
    cam_intrinsics = []
    for line in cam_intrinsic_lines:
        line_data_list = line.split(',')
        if len(line_data_list) == 0:
            continue
        cam_intrinsics.append([float(i) for i in line_data_list])

    """load camera poses"""
    assert os.path.isfile(pose_file), "camera info:{} not found".format(pose_file)
    with open(pose_file, "r") as f:
        cam_pose_lines = f.readlines()

    cam_poses = []
    for line in cam_pose_lines:
        line_data_list = line.split(',')
        if len(line_data_list) == 0:
            continue
        cam_poses.append([float(i) for i in line_data_list])

    
    lines = []
    ip = 0
    length = len(cam_poses)
    for i in range(len(cam_intrinsics)):
        while ip + 1< length and abs(cam_poses[ip + 1][0] - cam_intrinsics[i][0]) < abs(cam_poses[ip][0] - cam_intrinsics[i][0]):
            ip += 1
        cam_pose = cam_poses[ip][:4] + cam_poses[ip][5:] + [cam_poses[ip][4]]
        line = [str(a) for a in cam_pose]
        # line = [str(a) for a in cam_poses[ip]]
        line[0] = str(i).zfill(5)
        lines.append(' '.join(line) + '\n')
    
    dirname = os.path.dirname(out_file)
    if not os.path.exists(dirname):
        os.makedirs(dirname)

    with open(out_file, 'w') as f:
        f.writelines(lines)