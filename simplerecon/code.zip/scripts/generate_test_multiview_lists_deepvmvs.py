
"""Script for generating NeuralRecon multiview lists in the split folder indicated. 
    It will export these frame tuples in this format line by line in the output file: 
    scene_id frame_id_0 frame_id_1 ... frame_id_N
    
    Unlike generate_multiview_lists_neural_recon.py, this will generate a tuple for every frame,
    so frames will be repeated.

    Run like so for generating a list of 5 frame tuples in a window of 9 frames (default):
    
    python ./scripts/generate_multiview_lists_neural_recon_dense.py 
        --config_file configs/data_gen/data_gen_base.yaml 
        --mv_num_views 5
        --dynamic_data_dir /mnt/res_nas/mohameds/implicit_recon/multi_view_data/scannet
        --mv_split_filesuffix test_all_key_frames_deepmvs.txt
        --split test; 
    
    It will output a tuples file with a tuple list at:
    {dynamic_data_dir}/{split}{mv_split_filesuffix}

    This file uses the defaults in Options for frame relative differences, but you can change 
    them by passing values for these flags:
        max_keyframe_rotation
        max_keyframe_translation
"""

import copy
import os
import sys

sys.path.append("/".join(sys.path[0].split("/")[:-1]))
import random
import string
import time
from functools import partial
from multiprocessing import Manager
from multiprocessing.pool import Pool

import numpy as np
import options
import tools.keyframe_buffer
from datasets.arkit_neucon import ARKitDataset
from datasets.scannet_dataset import ScannetDataset
from datasets.seven_scenes_dataset import SevenScenesDataset
from datasets.scanniverse_dataset import ScanniverseDataset
from tqdm import tqdm


def pose_distance(reference_pose, measurement_pose):
    """
    :param reference_pose: 4x4 numpy array, reference frame camera-to-world pose (not extrinsic matrix!)
    :param measurement_pose: 4x4 numpy array, measurement frame camera-to-world pose (not extrinsic matrix!)
    :return combined_measure: float, combined pose distance measure
    :return R_measure: float, rotation distance measure
    :return t_measure: float, translation distance measure
    """
    rel_pose = np.dot(np.linalg.inv(reference_pose), measurement_pose)
    R = rel_pose[:3, :3]
    t = rel_pose[:3, 3]
    R_measure = np.sqrt(2 * (1 - min(3.0, np.matrix.trace(R)) / 3))
    t_measure = np.linalg.norm(t)
    combined_measure = np.sqrt(t_measure ** 2 + R_measure ** 2)
    return combined_measure, R_measure, t_measure

def is_valid_pair(reference_pose, measurement_pose, pose_dist_min, pose_dist_max, t_norm_threshold=0.05, return_measure=False):
    combined_measure, R_measure, t_measure = pose_distance(reference_pose, measurement_pose)

    if pose_dist_min <= combined_measure <= pose_dist_max and t_measure >= t_norm_threshold:
        result = True
    else:
        result = False

    if return_measure:
        return result, combined_measure
    else:
        return result

class Config:
    # training settings
    train_image_width = 256
    train_image_height = 256
    train_min_depth = 0.25
    train_max_depth = 20.0
    train_n_depth_levels = 64
    train_minimum_pose_distance = 0.125
    train_maximum_pose_distance = 0.325
    train_crawl_step = 3
    train_subsequence_length = None
    train_predict_two_way = None
    train_freeze_batch_normalization = False
    train_data_pipeline_workers = 8
    train_epochs = 100000
    train_print_frequency = 5000
    train_validate = True
    train_seed = int(round(time.time()))

    # test settings
    test_image_width = 320
    test_image_height = 256
    test_distortion_crop = 0
    test_perform_crop = False
    test_visualize = True
    test_n_measurement_frames = 2
    test_keyframe_buffer_size = 30
    test_keyframe_pose_distance = 0.1
    test_optimal_t_measure = 0.15
    test_optimal_R_measure = 0.0


def crawl_subprocess_long(opts_temp_filepath, scene, count, progress):
    item_list = []

    # load options file
    option_handler = options.OptionsHandler()
    option_handler.parse_and_merge_options(config_filepath=opts_temp_filepath, ignore_cl_args=True)
    opts = option_handler.options

    if opts.dataset == "scannet":
        dataset_class = ScannetDataset

    elif opts.dataset == "arkit_neucon":
        dataset_class = ARKitDataset

    elif opts.dataset == "7scenes":
        dataset_class = SevenScenesDataset

    elif opts.dataset == "scanniverse":
        dataset_class = ScanniverseDataset
    else:
        raise ValueError("Not a recognized dataset.")
    

    scan_dir = os.path.join(opts.dataset_path, dataset_class.get_sub_folder_dir(opts.split), scene.rstrip("\n"))
    valid_frame_path = os.path.join(scan_dir, "valid_frames.txt")
    with open(valid_frame_path) as f:
        valid_frames = f.readlines()
    
    frame_ind_to_frame_id = {}
    for frame_ind, frame_id in enumerate(valid_frames):
        frame_ind_to_frame_id[frame_ind] = int(frame_id.strip().split(" ")[1])

    ds = dataset_class(dataset_path=opts.dataset_path, 
                    mv_split_file_suffix=None,
                    split=opts.split,
                    split_file_location=opts.split_file_location,
                    pass_frame_id=True)

    poses = []
    for frame_ind in range(len(valid_frames)):
        frame_id = frame_ind_to_frame_id[frame_ind]
        world_T_cam_44, _ = ds.load_pose(scene.rstrip("\n"), frame_id)
        poses.append(world_T_cam_44)

    subsequence_length = opts.num_images_in_tuple
    n_measurement_frames = subsequence_length - 1

    keyframe_buffer = tools.keyframe_buffer.KeyframeBuffer(buffer_size=Config.test_keyframe_buffer_size,
                                        keyframe_pose_distance=Config.test_keyframe_pose_distance,
                                        optimal_t_score=Config.test_optimal_t_measure,
                                        optimal_R_score=Config.test_optimal_R_measure,
                                        store_return_indices=True)

    samples = []
    num_repeats = 0
    for i in range(0, len(poses)):
        sample = {'scene': scene,
                    'indices': [i]}
                
        reference_pose = poses[i]

        # POLL THE KEYFRAME BUFFER
        response = keyframe_buffer.try_new_keyframe(
            reference_pose, None, index=i
        )
        if response == 3:
            print("Tracking lost!")
        elif response == 1:
            measurement_frames = keyframe_buffer.get_best_measurement_frames(n_measurement_frames)
                
            for (measurement_pose, measurement_image, measurement_index) in measurement_frames:
                sample["indices"].append(measurement_index)
        
            samples.append(sample)


    for sample in samples:
        
        sampled_indices = sample["indices"]

        
        if len(sampled_indices) != subsequence_length:
            # not enough frames in the buffer. 

            # get all frames seen so far that aren't keyframes
            available_indices = list(range(0, sampled_indices[0]))
            available_indices = [frame_ind for frame_ind in available_indices if frame_ind not in sampled_indices]
            
            # pick from frames that haven't been touched yet (available_indices).
            diff = subsequence_length - len(sampled_indices)
            if diff > len(available_indices):
                diff = len(available_indices)
            sampled_indices += random.sample(available_indices, k=diff)

            # check again in case we still don't have enough and random sample repeat if we don't
            if len(sampled_indices) != subsequence_length:
                diff = subsequence_length - len(sampled_indices)
                num_repeats+=diff
                sampled_indices += random.choices(sampled_indices[1:], k=diff)

        assert len(sampled_indices) == subsequence_length

        chosen_frame_ids = [frame_ind_to_frame_id[frame_ind] for frame_ind in sampled_indices]

        item_list.append(
            f"{scene} {' '.join([str(frame_id) for frame_id in chosen_frame_ids])}"
        )

    progress.value += 1
    print(progress.value, "/", count, f"Repeated frames: {num_repeats} {len(item_list)} {len(poses)} {len(samples) <= len(poses)}", end='\r')

    return item_list

def crawl(opts_temp_filepath, opts, scenes, num_workers=1):
    pool = Pool(opts.num_workers)
    manager = Manager()

    count = len(scenes)
    progress = manager.Value('i', 0)

    item_list = []

    for scene_item_list in pool.imap_unordered(partial(crawl_subprocess_long,
                                                        opts_temp_filepath,
                                                        count=count,
                                                        progress=progress), scenes):
        item_list.extend(scene_item_list)

    return item_list

if __name__ == '__main__':

    
    # load options file
    option_handler = options.OptionsHandler()

    option_handler.parse_and_merge_options(ignore_cl_args=False)

    option_handler.pretty_print_options()

    opts = option_handler.options

    option_handler.save_options_as_yaml("config.yaml", opts)

    opts_temp_filepath = os.path.join(os.path.expanduser("~"), "tmp/", ''.join(random.choices(string.ascii_uppercase + string.digits, k=10)) + ".yaml")
    option_handler.save_options_as_yaml(opts_temp_filepath, opts)

    np.random.seed(42)
    random.seed(42)

    if opts.gpus == 0:
        print("Setting precision to 32 bits since --gpus is set to 0.")
        opts.precision = 32



    if opts.dataset == "scannet":
        dataset_class = ScannetDataset

    elif opts.dataset == "arkit_neucon":
        dataset_class = ARKitDataset

    elif opts.dataset == "7scenes":
        dataset_class = SevenScenesDataset

    elif opts.dataset == "scanniverse":
        dataset_class = ScanniverseDataset
        
    else:
        raise ValueError("Not a recognized dataset.")

    with open(opts.dataset_scene_split_file) as file:
        scan_names = file.readlines()
    scan_names = [scan_name.strip() for scan_name in scan_names]


    scan_dirs = [os.path.join(opts.dataset_path, dataset_class.get_sub_folder_dir(opts.split), scan_name.rstrip("\n")) for scan_name in scan_names]

    item_list = []

    split_filename = f"{opts.split}{opts.mv_split_file_suffix}"

    split_filepath = os.path.join(opts.split_file_location, split_filename)
    print(f"Saving to {split_filepath}")

    #crawl_subprocess_long(opts_temp_filepath, scan_names[0], 0, 1)

    item_list = crawl(opts_temp_filepath, opts, scan_names)

    with open(split_filepath, "w") as f:
        for line in item_list:
            f.write(line + "\n")
    print(f"Saved to {split_filepath}")

