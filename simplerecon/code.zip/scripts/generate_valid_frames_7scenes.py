"""Generates valid frame files for a 7Scenes folder by checking for invalid poses."""

import os
import numpy as np
from argparse import ArgumentParser

def get_scene_path(dataset_path, split_folder, scene_id):
        return os.path.join(dataset_path, split_folder, scene_id)

def get_color_filename(scene_path, frame_id):
    return os.path.join(
        scene_path, f"frame-{frame_id:06d}.color.png")

def get_depth_filename(scene_path, frame_id):
    return os.path.join(
        scene_path, f"frame-{frame_id:06d}.depth.png")

def get_pose_filename(scene_path, frame_id):
    return os.path.join(
        scene_path, f"frame-{frame_id:06d}.pose.txt")


def load_pose(scene_path, frame_id):

    pose_path = get_pose_filename(scene_path, frame_id)

    world_T_cam_44 = np.genfromtxt(pose_path)

    return world_T_cam_44

def main(args):

    scan_dirs = [x[0] for x in os.walk(args.seven_scenes_path) if "seq-" in x[0]]

    
    total_bad_count = 0
    total_frame_count = 0

    for scan_dir in scan_dirs:

        bad_file_count = 0
        
        all_frame_ids = [x[2] for x in os.walk(scan_dir)][0]
        all_frame_ids = [int(x.strip("frame-").strip(".pose.txt")) for x in all_frame_ids if ".pose.txt" in x]

        all_frame_ids.sort()

        scan_sub_dir = "/".join(scan_dir.split("/")[-2:])

        valid_frames = []
        for frame_id in all_frame_ids:

            color_filename = get_color_filename(scan_dir, frame_id)
            if not os.path.isfile(color_filename):
                bad_file_count+=1
                continue
            depth_filename = get_depth_filename(scan_dir, frame_id)
            if not os.path.isfile(depth_filename):
                bad_file_count+=1
                continue
            
            world_T_cam_44 = load_pose(scan_dir, frame_id)

            if np.isnan(np.sum(world_T_cam_44)) or np.isinf(np.sum(world_T_cam_44)) or np.isneginf(np.sum(world_T_cam_44)):
                bad_file_count+=1
                continue

                
            valid_frames.append(scan_sub_dir + " " + str(frame_id))


        valid_frame_path = os.path.join(scan_dir, "valid_frames.txt")
        with open(valid_frame_path, 'w') as f:
            f.write('\n'.join(valid_frames) + '\n')
   
        total_bad_count+=bad_file_count
        total_frame_count+=len(all_frame_ids)

        
        print(f"Scene {scan_sub_dir} has {bad_file_count} bad files out of {len(all_frame_ids)}.")

    print(f"Dataset has {total_bad_count} bad files out of {total_frame_count}.")

if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--seven_scenes_path', type=str, required=True)

    args = parser.parse_args()

    main(args)
