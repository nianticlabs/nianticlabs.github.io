"""Generates valid frame files for a NeuCon data folder by checking for invalid poses."""

import os
import sys

sys.path.append("/".join(sys.path[0].split("/")[:-1]))
from argparse import ArgumentParser

import numpy as np
from datasets.arkit_neucon import ARKitDataset


def main(args):

    scene_ids = [x[1] for x in os.walk(os.path.join(args.dataset_path, "scans"))][0]

    total_bad_count = 0
    total_frame_count = 0
    
    all_valid_frames = []
    bad_file_count = 0
    for scene_id in scene_ids:

        scan_dir = os.path.join(args.dataset_path, "scans", scene_id)

        print(os.path.join(scan_dir))

        ds = ARKitDataset(dataset_path=args.dataset_path, split=args.split, test_scene_id = scene_id, mv_split_file_suffix=None)

        all_frame_ids = [x[2] for x in os.walk(os.path.join(scan_dir, "images"))][0]
        all_frame_ids = [int(x.strip(".png")) for x in all_frame_ids if ".png" in x]

        all_frame_ids.sort()

        scan_sub_dir = "/".join(scan_dir.split("/")[-2:])

        valid_frames = []
        for frame_id in all_frame_ids:

            try:
                color_path = os.path.join(ds.scenes_path, scene_id, "images")
                color_filename = os.path.join(color_path, f"{frame_id:05d}.png")

                intrinsics = ds.get_intrinsics(scene_id, frame_id)

                world_T_cam, cam_T_world = ds.load_pose(scene_id, frame_id)

                # Load image
                image = ds.read_image_file(color_filename, height=ds.image_height, width=ds.image_width)

                if np.isnan(np.sum(world_T_cam)) or np.isinf(np.sum(world_T_cam)) or np.isneginf(np.sum(world_T_cam)):
                    bad_file_count+=1
                    continue

            except:
                if not os.path.isfile(color_filename):
                    bad_file_count+=1
                    continue
            
            valid_frames.append(scan_sub_dir + " " + str(frame_id))
            all_valid_frames.append(scan_sub_dir + " " + str(frame_id))


        valid_frame_path = os.path.join(scan_dir, "valid_frames.txt")
        with open(valid_frame_path, 'w') as f:
            f.write('\n'.join(valid_frames) + '\n')
   
        total_bad_count+=bad_file_count
        total_frame_count+=len(all_frame_ids)

        
        print(f"Scene {scan_sub_dir} has {bad_file_count} bad files out of {len(all_frame_ids)}.")

    valid_frame_path = os.path.join(args.dataset_path, "valid_frames.txt")
    with open(valid_frame_path, 'w') as f:
        f.write('\n'.join(all_valid_frames) + '\n')

    print(f"Dataset has {total_bad_count} bad files out of {total_frame_count}.")

if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--dataset_path', type=str, required=True)
    parser.add_argument('--split', type=str, default="test")


    args = parser.parse_args()

    main(args)
