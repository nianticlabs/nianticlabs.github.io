"""Generates valid frame files for a ScanNet folder by checking for invalid poses."""

import os
import numpy as np
from argparse import ArgumentParser

def get_scene_path(dataset_path, split_folder, scene_id):
        return os.path.join(dataset_path, split_folder, scene_id)

def get_color_filename(scene_path, frame_id):
    return os.path.join(
        scene_path, f"frame-{frame_id:06d}.color.png")

def get_depth_filename(scene_path, frame_id):
    return os.path.join(
        scene_path, f"frame-{frame_id:06d}.depth.png")

def get_pose_filename(scene_path, frame_id):
    return os.path.join(
        scene_path, f"frame-{frame_id:06d}.pose.txt")


def load_pose(scene_path, frame_id):

    pose_path = get_pose_filename(scene_path, frame_id)

    world_T_cam_44 = np.genfromtxt(pose_path)

    return world_T_cam_44

def main(args):

    with open(args.scene_split_file) as file:
        scan_names = file.readlines()

    scan_dirs = [os.path.join(args.seven_scenes_path, scan_name.rstrip("\n")) for scan_name in scan_names]

    all_valid_frames=[]
    for scan_dir in scan_dirs:

        valid_frame_path = os.path.join(scan_dir, "valid_frames.txt")
        with open(valid_frame_path) as f:
            valid_frames = f.readlines()
   
        all_valid_frames += valid_frames

    valid_frame_path = os.path.join(scan_dir, "valid_frames.txt")
    with open(args.output_filepath, 'w') as f:
        f.write("".join(all_valid_frames))


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--seven_scenes_path', type=str, required=True)
    parser.add_argument('--scene_split_file', type=str, required=True)
    parser.add_argument('--output_filepath', type=str, required=True)



    args = parser.parse_args()

    main(args)
