import os
from pathlib import Path

import pickle
import numpy as np
import open3d as o3d
import torch
import torch.nn.functional as F
import torchvision.transforms.functional as TF
import trimesh
from tqdm import tqdm

import experiment_modules.DepthModel as DepthModel
import options
from datasets.scannet_dataset import ScannetDataset
from datasets.seven_scenes_dataset import SevenScenesDataset
from datasets.arkit_neucon import ARKitDataset
from datasets.scanniverse_dataset import ScanniverseDataset
from tools.tsdf import TSDF, TSDFFuser
from tools import fusers_helper
from utils.generic_utils import (readlines, to_gpu)
from utils.metrics_utils import ResultsAverager, compute_depth_metrics_batched


def main(opts):

    # set precision to 32 bits.
    opts.precision = 32

    # figure out what dataset
    if opts.dataset == "scannet":

        with open(opts.dataset_scene_split_file) as file:
            scans = file.readlines()
            scans = [scan.strip() for scan in scans]
        
        if opts.single_scene_test_id is not None:
            scans = [opts.single_scene_test_id]

        dataset_class = ScannetDataset
        print(f"".center(80, "#"))
        print(f" ScanNet Dataset, number of scans: {len(scans)} ".center(80, "#"))
        print(f"".center(80, "#"))
        print("")


    elif opts.dataset == "arkit_neucon":
        
        with open(opts.dataset_scene_split_file) as file:
            scans = file.readlines()
            scans = [scan.strip() for scan in scans]

        if opts.single_scene_test_id is not None:
            scans = [opts.single_scene_test_id]

        dataset_class = ARKitDataset
        print(f"".center(80, "#"))
        print(f" ARKitDataset Dataset, number of scans: {len(scans)} ".center(80, "#"))
        print(f"".center(80, "#"))
        print("")


    elif opts.dataset == "scanniverse":

        with open(opts.dataset_scene_split_file) as file:
            scans = file.readlines()
            scans = [scan.strip() for scan in scans]

        if opts.single_scene_test_id is not None:
            scans = [opts.single_scene_test_id]

        dataset_class = ScanniverseDataset
        print(f"".center(80, "#"))
        print(f" ScanniverseDataset Dataset, number of scans: {len(scans)} ".center(80, "#"))
        print(f"".center(80, "#"))
        print("")


    elif opts.dataset == "7scenes":
        
        with open(opts.dataset_scene_split_file) as file:
            scans = file.readlines()
            scans = [scan.strip() for scan in scans]

        if opts.single_scene_test_id is not None:
            scans = [opts.single_scene_test_id]

        dataset_class = SevenScenesDataset
        print(f"".center(80, "#"))
        print(f" 7Scenes Dataset, number of scans: {len(scans)} ".center(80, "#"))
        print(f"".center(80, "#"))
        print("")

    else:
        raise ValueError("Not a recognized dataset.")

    
    if opts.run_fusion:
        mesh_output_path = f"{opts.fusion_output_base_path}{opts.name}_{opts.fusion_resolution}_{opts.fusion_max_depth}_{opts.depth_fuser}"
        
        if opts.mask_pred_depth:
            mesh_output_path = mesh_output_path + "_masked"
        if opts.fuse_color:
            mesh_output_path = mesh_output_path + "_color"
        
        mesh_output_path = mesh_output_path + "/scans_test/"

        Path(os.path.join(mesh_output_path)).mkdir(parents=True, exist_ok=True)
        print(f"".center(80, "#"))
        print(f" Running Fusion! Using {opts.depth_fuser} ".center(80, "#"))
        print(f"Output directory: {mesh_output_path} ".center(80, "#"))
        print(f"".center(80, "#"))
        print("")


    if opts.cache_depths:
        depth_output_path = f"{opts.depth_output_base_path}{opts.name}_raw/scans_test/"
        Path(os.path.join(depth_output_path)).mkdir(parents=True, exist_ok=True)
        print(f"".center(80, "#"))
        print(f" Caching Depths!".center(80, "#"))
        print(f"Output directory: {depth_output_path} ".center(80, "#"))
        print(f"".center(80, "#"))
        print("")


    model = DepthModel.DepthModel.load_from_checkpoint(opts.load_weights_from_checkpoint, args=None)
    model = model.cuda().eval()

    all_frame_metrics = None
    all_scene_metrics = None

    all_frame_metrics = ResultsAverager(opts.name, f"frame metrics")
    all_scene_metrics = ResultsAverager(opts.name, f"scene metrics")

    with torch.inference_mode():
        for scan in tqdm(scans):
            
            # initialize fuser if we need to fuse
            if opts.run_fusion:
                fuser = fusers_helper.get_fuser(opts, scan)

            # set up dataset with current scan
            dataset = dataset_class(opts.dataset_path,
                                    split="test",
                                    mv_split_file_suffix=opts.mv_split_file_suffix,
                                    test_scene_id=scan,
                                    load_full_res_depth=True,
                                    split_file_location=opts.split_file_location,
                                    num_images_in_tuple=None,
                                    shuffle_tuple=opts.shuffle_tuple,
                                    load_full_res_color=opts.fuse_color and opts.run_fusion,
                                    include_full_depth_K=True,
                                    skip_frames=opts.skip_frames,
                                    image_width=opts.image_width,
                                    image_height=opts.image_height,
                                    pass_frame_id=True)

            dataloader = torch.utils.data.DataLoader(dataset, 
                                                    batch_size=opts.batch_size, 
                                                    shuffle=False, 
                                                    num_workers=opts.num_workers, 
                                                    drop_last=False)

            # initialize scene averager
            scene_frame_metrics = ResultsAverager(opts.name, f"scene {scan} metrics")

            for batch in tqdm(dataloader):
                
                # get data, move to GPU
                cur_data, ref_data = batch

                cur_data = to_gpu(cur_data)
                ref_data = to_gpu(ref_data)

                outputs = model("test", cur_data, ref_data, unbatched_matching_encoder_forward=True, return_mask=True)
                depth_pred = outputs["depth_pred_s0_b1hw"]
                depth_gt = cur_data["full_res_depth_b1hw"]

                upsampled_depth_pred_b1hw = F.upsample(depth_pred, size=(depth_gt.shape[-2], depth_gt.shape[-1]), mode="nearest")

                # inf max depth matches DVMVS metrics
                valid_mask_b = (depth_gt > 0.5)# & (depth_gt < 10)

                # No valid points in this sample
                if (~valid_mask_b).all():
                    continue
                
                # compute metrics
                metrics_b_dict = compute_depth_metrics_batched(depth_gt.flatten(start_dim=1).float(), 
                                                            upsampled_depth_pred_b1hw.flatten(start_dim=1).float(), 
                                                            valid_mask_b.flatten(start_dim=1),
                                                            mult_a=True)

                # go over batch and get metrics frame by frame to update the averagers 
                for element_index in range(depth_gt.shape[0]):
                    element_metrics = {}
                    if (~valid_mask_b[element_index]).all():
                        continue
                    for key in list(metrics_b_dict.keys()):
                        element_metrics[key] = metrics_b_dict[key][element_index]
                    
                    # both scene and frame averagers
                    scene_frame_metrics.update_results(element_metrics)
                    all_frame_metrics.update_results(element_metrics)

                # if we should fuse, then pass to the fuser
                if opts.run_fusion:
                    if opts.mask_pred_depth:
                        overall_mask_b1hw = F.upsample(outputs["overall_mask_bhw"].cuda().unsqueeze(1).float(), size=(depth_gt.shape[-2], depth_gt.shape[-1]), mode="nearest").bool()
                        upsampled_depth_pred_b1hw[~overall_mask_b1hw] = -1
                    
                    if opts.fusion_use_raw_lowest_cost:
                        upsampled_depth_pred_b1hw = F.upsample(outputs["lowest_cost_b1hw"].unsqueeze(0), size=(depth_gt.shape[-2], depth_gt.shape[-1]), mode="nearest")
                        overall_mask_b1hw = F.upsample(outputs["overall_mask_bhw"].cuda().unsqueeze(1).float(), size=(depth_gt.shape[-2], depth_gt.shape[-1]), mode="nearest").bool()
                        upsampled_depth_pred_b1hw[~overall_mask_b1hw] = -1
                    
                    fuser.fuse_frames(upsampled_depth_pred_b1hw, cur_data["K_full_depth_b44"], cur_data["cam_T_world_b44"], cur_data["full_res_color_b3hw"])

                if opts.cache_depths:
                    Path(os.path.join(depth_output_path, scan)).mkdir(parents=True, exist_ok=True)

                    frame_id = int(cur_data["frame_id"][0])
                    output_path = os.path.join(depth_output_path, scan, f"{frame_id}.pickle")

                    outputs["K_full_depth_b44"] = cur_data["K_full_depth_b44"]
                    outputs["K_s0_b44"] = cur_data["K_s0_b44"]
                    outputs["frame_id"] = cur_data["frame_id"]
                    outputs["ref_ids"] = ref_data["frame_id"]

                    with open(output_path, 'wb') as handle:
                        pickle.dump(outputs, handle)


            # save the fused tsdf into a mesh file
            if opts.run_fusion:
                if opts.fuse_color:
                    fuser.export_mesh(os.path.join(mesh_output_path, f"{scan}_tsdf_{opts.fusion_resolution}_{opts.fusion_max_depth}_{opts.depth_fuser}_color.ply"))
                else:
                    fuser.export_mesh(os.path.join(mesh_output_path, f"{scan}_tsdf_{opts.fusion_resolution}_{opts.fusion_max_depth}_{opts.depth_fuser}.ply"))


            # compute a clean average using numpy
            scene_frame_metrics.compute_final_average()
            
            # print running metrics.
            print("\nRunning metrics:")
            all_scene_metrics.update_results(scene_frame_metrics.final_metrics)
            all_scene_metrics.print_sheets_friendly(include_metrics_names=True)
            all_frame_metrics.print_sheets_friendly(include_metrics_names=True)

        # compute and print final average
        print("\nFinal metrics:")
        all_scene_metrics.compute_final_average()
        all_scene_metrics.pretty_print_results(running_metrics=False)
        all_scene_metrics.print_sheets_friendly(include_metrics_names=True, running_metrics=False)
        
        print("")
        all_frame_metrics.compute_final_average()
        all_frame_metrics.pretty_print_results(running_metrics=False)
        all_frame_metrics.print_sheets_friendly(include_metrics_names=True, running_metrics=False)

if __name__ == '__main__':
    torch.set_grad_enabled(False)

    option_handler = options.OptionsHandler()

    option_handler.parse_and_merge_options()

    option_handler.pretty_print_options()
    print("")


    opts = option_handler.options

    if opts.gpus == 0:
        print("Setting precision to 32 bits since --gpus is set to 0.")
        opts.precision = 32

    main(opts)
