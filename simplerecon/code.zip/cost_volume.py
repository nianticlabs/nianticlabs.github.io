import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

from networks import MLP
from utils.generic_utils import combine_dims, tensor_B_to_bM, tensor_bM_to_B
from utils.geometry_utils import (BackprojectDepth, Project3D,
                                  get_camera_rays, pose_distance)

class CostVolumeManager(nn.Module):

    """Class to build a cost volume from extracted features from input image and N reference images.

    Achieved by backwarping reference features onto current features using hypothesised
    depths between min_depth_bin and max_depth_bin, and taking the abs diff between features at each
    pixel location. We then average over the feature dimension, resulting in a
    batch_size x num_depths x H x  W tensor.

    """

    def __init__(self, matching_height, matching_width, num_depth_bins=64):

        """

        :param matching_height: height of input feature maps
        :param matching_width: width of input feature maps
        :param num_depth_bins: number of depth planes used for warping

        """
        super().__init__()

        self.num_depth_bins = num_depth_bins
        self.matching_height = matching_height
        self.matching_width = matching_width

        self.initialise_for_projection()


    def initialise_for_projection(self):

        """
        Set up for backwarping of feature maps
        :param batch_height: height of the current batch of features
        :param batch_width: width of the current batch of features
        """

        linear_ramp = torch.linspace(0, 1, self.num_depth_bins).view(1, self.num_depth_bins, 1, 1)
        self.register_buffer("linear_ramp_1d11", linear_ramp)

        self.backprojector = BackprojectDepth(height=self.matching_height,
                                              width=self.matching_width)
        self.projector = Project3D()


    def get_mask(self, pix_coords_bk2hw):

        """
        Create a mask to ignore a) features from the edge of our current image, and b) features
        from the edges or outside of reference images
        :param uv_coords: sampling locations of reference features
        :return: mask: a binary mask indicating whether to ignore a pixels
        """

        mask = torch.logical_and(
                    torch.logical_and(pix_coords_bk2hw[:, :, 0] > 2, pix_coords_bk2hw[:, :, 0] < self.matching_width - 2),
                    torch.logical_and(pix_coords_bk2hw[:, :, 1] > 2, pix_coords_bk2hw[:, :, 1] < self.matching_height - 2))

        return mask

    def generate_depth_planes(self, batch_size: int, min_depth: Tensor, max_depth: Tensor) -> Tensor:

        linear_ramp_bd11 = self.linear_ramp_1d11.expand(batch_size, self.num_depth_bins, 1, 1)
        log_depth_planes_bd11 = torch.log(min_depth) + torch.log(max_depth / min_depth) * linear_ramp_bd11
        depth_planes_bd11 = torch.exp(log_depth_planes_bd11)
        depth_planes_bdhw = depth_planes_bd11.expand(batch_size, self.num_depth_bins, self.matching_height, self.matching_width)

        return depth_planes_bdhw


    def warp_features(self, 
                    ref_feats, 
                    ref_poses, 
                    ref_Ks, 
                    cur_invK, 
                    depth_plane_b1hw, 
                    batch_size, 
                    num_ref_frames, 
                    num_feat_channels,
                    uv_scale):
                    
        world_points_b4N = self.backprojector(depth_plane_b1hw, cur_invK)
        world_points_B4N = world_points_b4N.repeat_interleave(num_ref_frames, dim=0)

        # Warp features and reshape
        cam_points_B3N = self.projector(world_points_B4N, ref_Ks.view(-1, 4, 4), ref_poses.view(-1, 4, 4))

        cam_points_B3hw = cam_points_B3N.view(-1, 3, self.matching_height, self.matching_width)
        pix_coords_B2hw = cam_points_B3hw[:, :2]
        depths = cam_points_B3hw[:, 2:]

        uv_coords = 2 * pix_coords_B2hw.permute(0, 2, 3, 1) * uv_scale - 1

        ref_feat_warped = F.grid_sample(input=ref_feats.view(-1, num_feat_channels, self.matching_height, self.matching_width),
                                            grid=uv_coords.type_as(ref_feats),
                                            padding_mode='zeros',
                                            mode='bilinear',
                                            align_corners=False)

        # Reshape tensors to "unbatch"
        ref_feat_warped = ref_feat_warped.view(batch_size,
                                                   num_ref_frames,
                                                   num_feat_channels,
                                                   self.matching_height,
                                                   self.matching_width)
        # pix_coords_bk2hw = pix_coords_B2hw.view(batch_size,
        #                                         num_ref_frames,
        #                                         2,
        #                                         self.matching_height,
        #                                         self.matching_width)
        depths = depths.view(batch_size,
                                 num_ref_frames,
                                 self.matching_height,
                                 self.matching_width)

        # mask values landing outside the image and optionally near the border
        # mask_b = torch.logical_and(self.get_mask(pix_coords_bk2hw), depths > 0)
        mask_b = depths > 0
        mask = mask_b.type_as(ref_feat_warped)
                             
        return world_points_B4N, depths, ref_feat_warped, mask

    def build_cost_volume(self, cur_feats: Tensor,
                                ref_feats: Tensor,
                                ref_poses: Tensor,
                                inv_ref_poses: Tensor,
                                ref_Ks: Tensor,
                                cur_invK: Tensor,
                                min_depth: Tensor,
                                max_depth: Tensor,
                                depth_planes_bdhw: Tensor = None,
                                return_mask: bool = False):

        """
        Build the cost volume. Using hypothesised depths, we backwarp ref_feats onto cur_feats
        using known intrinsics and take the abs difference. We average costs over ref_feats.

        :param cur_feats: input image features - B x C x H x W
        :param ref_feats: reference image features - B x num_ref_frames x C x H x W
        :param ref_poses: reference image camera poses - B x num_ref_frames x 4 x 4
        :param ref_Ks: reference image inverse intrinsics - B x num_ref_frames x 4 x 4
        :param cur_invK: current image intrinsics - B x 4 x 4
        """

        # to deal with different sized batches (e.g. landscape/portrait) set up projection
        # here, not in __init__
        batch_size, num_ref_frames, num_feat_channels, ref_feat_height, ref_feat_width = ref_feats.shape

        uv_scale = torch.tensor([1 / self.matching_width, 1 / self.matching_height], dtype=ref_poses.dtype, device=ref_poses.device).view(1, 1, 1, 2)

        if depth_planes_bdhw is None:
            depth_planes_bdhw = self.generate_depth_planes(batch_size, min_depth, max_depth)

        # Intialize the cost volume and the counts
        all_dps = []

        # loop through ref images adding to the current cost volume
        for depth_id in range(self.num_depth_bins):

            depth_plane_b1hw = depth_planes_bdhw[:, depth_id].unsqueeze(1)
            _, _, ref_feat_warped, mask = self.warp_features(ref_feats, 
                                                            ref_poses, 
                                                            ref_Ks, 
                                                            cur_invK, 
                                                            depth_plane_b1hw, 
                                                            batch_size, 
                                                            num_ref_frames, 
                                                            num_feat_channels,
                                                            uv_scale)


            # Compute the dot product between cur and ref features
            dot_product_bkhw = torch.sum(ref_feat_warped * cur_feats.unsqueeze(1), dim=2) * mask

            # Sum over the frames
            dot_product_b1hw = dot_product_bkhw.sum(dim=1, keepdim=True)

            all_dps.append(dot_product_b1hw)

        cost_volume = torch.cat(all_dps, dim=1)

        return cost_volume, depth_planes_bdhw, None

    def indices_to_disparity(self, indices, depth_planes_bdhw):
        """Convert cost volume indices to 1/depth for visualisation"""
        depth = torch.gather(depth_planes_bdhw, dim=1, index=indices.unsqueeze(1)).squeeze(1)
        return depth

    def forward(self, cur_feats, ref_feats, ref_poses, inv_ref_poses, ref_Ks, cur_invK, min_depth, max_depth, depth_planes_bdhw=None, return_mask=False):
        """ Runs the cost volume and gets the lowest cost result
        """
        cost_volume, depth_planes_bdhw, overall_mask_bhw= \
            self.build_cost_volume(cur_feats=cur_feats,
                                   ref_feats=ref_feats,
                                   ref_poses=ref_poses,
                                   ref_Ks=ref_Ks,
                                   cur_invK=cur_invK,
                                   inv_ref_poses=inv_ref_poses,
                                   min_depth=min_depth,
                                   max_depth=max_depth,
                                   depth_planes_bdhw=depth_planes_bdhw,
                                   return_mask = return_mask)

        # for visualisation - ignore 0s in cost volume for minimum
        with torch.no_grad():
            lowest_cost = self.indices_to_disparity(torch.argmax(cost_volume.detach(), 1), depth_planes_bdhw)

        return cost_volume, lowest_cost, depth_planes_bdhw, overall_mask_bhw

class FeatureVolumeManager(CostVolumeManager):

    """Class to build a feature volume from extracted features from input image and N reference images.

    Achieved by backwarping reference features onto current features using hypothesised
    depths between min_depth_bin and max_depth_bin, and taking the abs diff between features at each
    pixel location. We then run an MLP over the feature dimension, resulting in a
    batch_size x num_depths x H x  W tensor.

    """

    def __init__(self, 
                matching_height, 
                matching_width, 
                num_depth_bins=64, 
                mlp_channels=[202,128,128,1], 
                matching_dim_size = 16,
                num_reference_views = 7):
        """

        :param matching_height: height of input feature maps
        :param matching_width: width of input feature maps
        :param num_depth_bins: number of depth planes used for warping

        """
        super().__init__(matching_height, matching_width, num_depth_bins)

        num_visual_channels = matching_dim_size * (1 + num_reference_views)
        num_depth_channels = 1 + num_reference_views
        num_ray_channels = 3 * (1 + num_reference_views)
        num_ray_angle_channels = num_reference_views
        num_mask_channels = num_reference_views
        num_num_dot_channels = num_reference_views        
        num_pose_penalty_channels = 3 * (num_reference_views)


        mlp_channels[0] = num_visual_channels \
                        + num_depth_channels  \
                        + num_ray_channels    \
                        + num_ray_angle_channels \
                        + num_mask_channels \
                        + num_num_dot_channels \
                        + num_pose_penalty_channels

        self.mlp = MLP(channel_list=mlp_channels, disable_final_activation=True)

        print(f"".center(80, "#"))
        print(f" Using FeatureVolumeManager ".center(80, "#"))
        print(f" Number of reference views: ".ljust(30, " ") + f"{num_reference_views}  ")
        print(f" Using all metadata.  ")
        print(f" Number of channels: ".ljust(30, " ") + f"{mlp_channels}  ")
        print(f"".center(80, "#"))
        print("")


    def build_cost_volume(self, cur_feats: Tensor,
                                ref_feats: Tensor,
                                ref_poses: Tensor,
                                inv_ref_poses: Tensor,
                                ref_Ks: Tensor,
                                cur_invK: Tensor,
                                min_depth: Tensor,
                                max_depth: Tensor,
                                depth_planes_bdhw: Tensor = None,
                                return_mask: bool = False):

        """
        Build the feature volume. Using hypothesised depths, we backwarp ref_feats onto cur_feats
        using known intrinsics and take the abs difference. We average costs over ref_feats.

        :param cur_feats: input image features - B x C x H x W
        :param ref_feats: reference image features - B x num_ref_frames x C x H x W
        :param ref_poses: reference image camera poses - B x num_ref_frames x 4 x 4
        :param ref_Ks: reference image inverse intrinsics - B x num_ref_frames x 4 x 4
        :param cur_invK: current image intrinsics - B x 4 x 4
        """

        # to deal with different sized batches (e.g. landscape/portrait) set up projection
        # here, not in __init__
        batch_size, num_ref_frames, num_feat_channels, ref_feat_height, ref_feat_width = ref_feats.shape

        uv_scale = torch.tensor([1 / self.matching_width, 1 / self.matching_height], dtype=ref_poses.dtype, device=ref_poses.device).view(1, 1, 1, 2)

        if depth_planes_bdhw is None:
            depth_planes_bdhw = self.generate_depth_planes(batch_size, min_depth, max_depth)


        frame_penalty_B, r_measure_B, t_measure_B = pose_distance(tensor_bM_to_B(inv_ref_poses))
        frame_penalty_bkhw = tensor_B_to_bM(frame_penalty_B, 
                                            batch_size=batch_size, 
                                            num_views=num_ref_frames)[:,:,None,None].expand(batch_size, num_ref_frames, ref_feat_height, ref_feat_width)
        r_measure_bkhw = tensor_B_to_bM(r_measure_B, batch_size=batch_size, num_views=num_ref_frames)[:,:,None,None].expand(frame_penalty_bkhw.shape)
        t_measure_bkhw = tensor_B_to_bM(t_measure_B, batch_size=batch_size, num_views=num_ref_frames)[:,:,None,None].expand(frame_penalty_bkhw.shape)

        overall_mask_bhw = None
        if return_mask:
            overall_mask_bhw = torch.zeros((batch_size,
                                    self.matching_height,
                                    self.matching_width),
                                    device=ref_feats.device,
                                    dtype=torch.bool)

        # Intialize the cost volume and the counts
        all_dps = []

        # loop through ref images adding to the current cost volume
        for depth_id in range(self.num_depth_bins):
            
            depth_plane_b1hw = depth_planes_bdhw[:, depth_id].unsqueeze(1)

            world_points_b4N = self.backprojector(depth_plane_b1hw, cur_invK)
            world_points_B4N = world_points_b4N.repeat_interleave(num_ref_frames, dim=0)

            # Warp features and reshape
            cam_points_B3N = self.projector(world_points_B4N, ref_Ks.view(-1, 4, 4), ref_poses.view(-1, 4, 4))

            cam_points_B3hw = cam_points_B3N.view(-1, 3, self.matching_height, self.matching_width)
            pix_coords_B2hw = cam_points_B3hw[:, :2]
            depths = cam_points_B3hw[:, 2:]

            uv_coords = 2 * pix_coords_B2hw.permute(0, 2, 3, 1) * uv_scale - 1

            ref_feat_warped = F.grid_sample(input=ref_feats.view(-1, num_feat_channels, self.matching_height, self.matching_width),
                                                grid=uv_coords.type_as(ref_feats),
                                                padding_mode='zeros',
                                                mode='bilinear',
                                                align_corners=False)

            # Reshape tensors to "unbatch"
            ref_feat_warped = ref_feat_warped.view(batch_size,
                                                    num_ref_frames,
                                                    num_feat_channels,
                                                    self.matching_height,
                                                    self.matching_width)
            # pix_coords_bk2hw = pix_coords_B2hw.view(batch_size,
            #                                         num_ref_frames,
            #                                         2,
            #                                         self.matching_height,
            #                                         self.matching_width)
            depths = depths.view(batch_size,
                                    num_ref_frames,
                                    self.matching_height,
                                    self.matching_width)

            # mask values landing outside the image and optionally near the border
            # mask_b = torch.logical_and(self.get_mask(pix_coords_bk2hw), depths > 0)
            mask_b = depths > 0
            mask = mask_b.type_as(ref_feat_warped)
            

            if return_mask:
                depth_mask = torch.any(mask_b, dim=1)
                pix_coords_bk2hw = pix_coords_B2hw.view(batch_size,
                                        num_ref_frames,
                                        2,
                                        self.matching_height,
                                        self.matching_width)
                bounds_mask = torch.any(self.get_mask(pix_coords_bk2hw), dim=1)
                overall_mask_bhw = torch.logical_and(depth_mask, bounds_mask)
                
                                
            # compute rays to world points for current frame 
            cur_points_rays_B3hw = torch.nn.functional.normalize(world_points_B4N[:,:3,:], dim=1).view(-1, 3, self.matching_height, self.matching_width)
            cur_points_rays_bk3hw = tensor_B_to_bM(cur_points_rays_B3hw, batch_size=batch_size, num_views=num_ref_frames)
            
            # compute rays for world points reference frame 
            inv_ref_poses_B44 = tensor_bM_to_B(inv_ref_poses)
            ref_points_rays_B3hw = get_camera_rays(inv_ref_poses_B44,
                                            world_points_B4N[:,:3,:],
                                            in_camera_frame=False).view(-1, 3, self.matching_height, self.matching_width)
            ref_points_rays_bk3hw = tensor_B_to_bM(ref_points_rays_B3hw, batch_size=batch_size, num_views=num_ref_frames)

            # combine current and reference rays
            all_rays_bchw = combine_dims(torch.cat([cur_points_rays_bk3hw[:,0,:,:,:][:,None,:,:,:], ref_points_rays_bk3hw],dim=1), 1, 3)

            # compute angle difference between rays (dot product)
            ray_angle_bkhw = torch.nn.functional.cosine_similarity(cur_points_rays_bk3hw, ref_points_rays_bk3hw, dim=2, eps=1e-5)

            # Compute the dot product between cur and ref features
            dot_product_bkhw = torch.sum(ref_feat_warped * cur_feats.unsqueeze(1), dim=2) * mask

            # combine all visual features from across all images
            combined_visual_features_bchw = combine_dims(torch.cat([ref_feat_warped, cur_feats.unsqueeze(1)], dim=1), 1, 3)

            mlp_input_features_bchw = torch.cat([combined_visual_features_bchw,
                                        mask, 
                                        depths, 
                                        depth_plane_b1hw, 
                                        dot_product_bkhw, 
                                        ray_angle_bkhw, 
                                        all_rays_bchw, 
                                        frame_penalty_bkhw, 
                                        r_measure_bkhw, 
                                        t_measure_bkhw], dim=1)

            mlp_input_features_bhwc = mlp_input_features_bchw.permute(0,2,3,1)
            feature_b1hw = self.mlp(mlp_input_features_bhwc).squeeze(-1).unsqueeze(1)

            all_dps.append(feature_b1hw)

        feature_volume = torch.cat(all_dps, dim=1)

        return feature_volume, depth_planes_bdhw, overall_mask_bhw