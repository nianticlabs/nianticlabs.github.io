import torch
from torch import Tensor
import torch.nn as nn
from typing import Type, Any, Callable, Union, List, Optional
from functools import partial


def conv3x3(in_planes: int, out_planes: int, stride: int = 1, groups: int = 1, dilation: int = 1, bias: bool = False) -> nn.Conv2d:
    """3x3 convolution with padding"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride,
                     padding=dilation, groups=groups, bias=bias, dilation=dilation)


def conv1x1(in_planes: int, out_planes: int, stride: int = 1, bias: bool = False) -> nn.Conv2d:
    """1x1 convolution"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=1, stride=stride, bias=bias)

@torch.jit.script
def square_plus(x: Tensor, a: Tensor = torch.tensor(1.52382103)):
    return 0.5 * (x + torch.sqrt(torch.square(x) + torch.square(a)))

class BasicBlock(nn.Module):
    expansion: int = 1

    def __init__(
        self,
        inplanes: int,
        planes: int,
        stride: int = 1,
        groups: int = 1,
        base_width: int = 64,
        dilation: int = 1,
        norm_layer: Optional[Callable[..., nn.Module]] = nn.Identity,
    ) -> None:
        super(BasicBlock, self).__init__()
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        if groups != 1 or base_width != 64:
            raise ValueError('BasicBlock only supports groups=1 and base_width=64')
        if dilation > 1:
            raise NotImplementedError("Dilation > 1 not supported in BasicBlock")
        if norm_layer == nn.Identity:
            bias = True
        else:
            bias = False
        # Both self.conv1 and self.downsample layers downsample the input when stride != 1
        self.conv1 = conv3x3(inplanes, planes, stride, bias=bias)
        self.bn1 = norm_layer(planes)
        # self.relu = nn.ReLU(inplace=True)
        self.relu = nn.LeakyReLU(0.2, inplace=True)
        # self.relu = nn.ReLU6(True)
        # self.relu = nn.SiLU(inplace=True)
        # self.relu = nn.ELU(inplace=True)
        self.conv2 = conv3x3(planes, planes, bias=bias)
        self.bn2 = norm_layer(planes)
        if inplanes == planes * self.expansion and stride == 1:
            self.downsample = None
        else:
            conv = conv1x1 if stride == 1 else conv3x3
            self.downsample = nn.Sequential(
                conv(inplanes, planes * self.expansion, bias=bias, stride=stride),
                norm_layer(planes * self.expansion))
        self.stride = stride

        # self.se = SEBlock(planes)

    def forward(self, x: Tensor) -> Tensor:
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        # out = self.se(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)

        return out


class Bottleneck(nn.Module):
    # Bottleneck in torchvision places the stride for downsampling at 3x3 convolution(self.conv2)
    # while original implementation places the stride at the first 1x1 convolution(self.conv1)
    # according to "Deep residual learning for image recognition"https://arxiv.org/abs/1512.03385.
    # This variant is also known as ResNet V1.5 and improves accuracy according to
    # https://ngc.nvidia.com/catalog/model-scripts/nvidia:resnet_50_v1_5_for_pytorch.

    expansion: int = 4

    def __init__(
        self,
        inplanes: int,
        planes: int,
        stride: int = 1,
        groups: int = 1,
        base_width: int = 64,
        dilation: int = 1,
        norm_layer: Optional[Callable[..., nn.Module]] = nn.Identity,
    ) -> None:
        super().__init__()
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        width = int(planes * (base_width / 64.0)) * groups
        if norm_layer == nn.Identity:
            bias = True
        else:
            bias = False
        # Both self.conv2 and self.downsample layers downsample the input when stride != 1
        self.conv1 = conv1x1(inplanes, width, bias=bias)
        self.bn1 = norm_layer(width)
        self.conv2 = conv3x3(width, width, stride, groups, dilation, bias=bias)
        self.bn2 = norm_layer(width)
        self.conv3 = conv1x1(width, planes * self.expansion, bias=bias)
        self.bn3 = norm_layer(planes * self.expansion)
        self.relu = nn.LeakyReLU(inplace=True)
        if inplanes == planes * self.expansion and stride == 1:
            self.downsample = None
        else:
            self.downsample = nn.Sequential(
                conv1x1(inplanes, planes * self.expansion, bias=bias),
                norm_layer(planes * self.expansion))
        self.stride = stride

    def forward(self, x: Tensor) -> Tensor:
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)

        return out


class SEBlock(nn.Module):
    def __init__(self, c, r=16):
        super().__init__()

        self.se = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(c, c // r, kernel_size=1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(c // r, c, kernel_size=1, bias=False),
            nn.Sigmoid(),
        )

    def forward(self, x):
        return x * self.se(x)


class FusedMBConv(nn.Module):
    def __init__(self, num_ch_in, num_ch_out, exp_ratio=4):
        super().__init__()

        self.activation_fn = nn.LeakyReLU(0.2, True)

        self.mbconv = nn.Sequential(
            nn.Conv2d(num_ch_in, num_ch_in * exp_ratio, kernel_size=3, padding=1),
            self.activation_fn,
            # SEBlock(num_ch_in * exp_ratio),
            nn.Conv2d(num_ch_in * exp_ratio, num_ch_out, kernel_size=1, padding=0)
        )

        self.downsample = None
        if num_ch_in != num_ch_out:
            self.downsample = nn.Conv2d(num_ch_in, num_ch_out, 1)

    def forward(self, x):
        identity = x

        out = self.mbconv(x)
        if self.downsample is not None:
            identity = self.downsample(x)

        out = self.activation_fn(out + identity)

        return out

class TensorFormatter(nn.Module):
    """Helper to format, apply operation, format back tensor.

    Class to format tensors of shape B x D x C_i x H x W into B*D x C_i x H x W,
    apply an operation, and reshape back into B x D x C_o x H x W.

    Used for multidepth - batching feature extraction on reference images"""

    def __init__(self):
        super().__init__()

        self.batch_size = None
        self.depth_chns = None

    def _expand_batch_with_channels(self, x):
        if x.dim() != 5:
            raise ValueError('TensorFormatter expects tensors with 5 dimensions, '
                             'not {}!'.format(len(x.shape)))
        self.batch_size, self.depth_chns, chns, height, width = x.shape
        x = x.view(self.batch_size * self.depth_chns, chns, height, width)
        return x

    def _reduce_batch_to_channels(self, x):
        if self.batch_size is None or self.depth_chns is None:
            raise ValueError('Cannot  call _reduce_batch_to_channels without first calling'
                             '_expand_batch_with_channels!')
        _, chns, height, width = x.shape
        x = x.view(self.batch_size, self.depth_chns, chns, height, width)
        return x

    def forward(self, x, apply_func):
        x = self._expand_batch_with_channels(x)
        x = apply_func(x)
        x = self._reduce_batch_to_channels(x)
        return x