import pytorch_lightning as pl
import timm
import torch
import torch.nn.functional as F
import torchvision.transforms.functional as TF
from cost_volume import CostVolumeManager, FeatureVolumeManager
from layers import TensorFormatter
from losses import MSGradientLoss, MVDepthLoss, NormalsLoss, ScaleInvariantLoss
from networks import (CVEncoder, DepthDecoderPP, FPNMatchingEncoder,
                      ResnetMatchingEncoder)
from torch import nn
from utils.generic_utils import tensor_B_to_bM, tensor_bM_to_B
from utils.geometry_utils import NormalGenerator
from utils.metrics_utils import compute_depth_metrics
from utils.visualization_utils import colormap_image


class DepthModel(pl.LightningModule):
    def __init__(self, opts):
        super().__init__()
        self.save_hyperparameters()

        self.run_opts = opts

        if "efficientnet" in self.run_opts.image_encoder_name:
            self.encoder = timm.create_model("tf_efficientnetv2_s_in21ft1k", pretrained=True, features_only=True)
            self.encoder.num_ch_enc = self.encoder.feature_info.channels()
        else:
            raise ValueError("Unrecognized option for image encoder type!")

        if self.run_opts.cv_encoder_type == "multi_scale_encoder":
            self.cost_volume_net = CVEncoder(
                num_ch_cv=self.run_opts.matching_num_depth_bins,
                num_ch_enc=self.encoder.num_ch_enc[self.run_opts.matching_scale:],
                num_ch_outs=[64, 128, 256, 384])
            dec_num_input_ch = self.encoder.num_ch_enc[:self.run_opts.matching_scale] + self.cost_volume_net.num_ch_enc
        else:
            raise ValueError("Unrecognized option for cost volume encoder type!")

        if self.run_opts.depth_decoder_name == "unet_pp":
            self.depth_decoder = DepthDecoderPP(dec_num_input_ch)
        else:
            raise ValueError("Unrecognized option for depth decoder name!")

        self.si_loss = ScaleInvariantLoss()
        self.grad_loss = MSGradientLoss()
        self.abs_loss = nn.L1Loss()
        self.normals_loss = NormalsLoss()
        self.mv_depth_loss = MVDepthLoss(self.run_opts.image_height // 2, self.run_opts.image_width // 2)

        # Pick the multiscale loss
        if self.run_opts.loss_type == "log_l1":
            self.ms_loss_fn = self.abs_loss
        else:
            raise ValueError(f"loss_type: {self.run_opts.loss_type} unknown")

        self.compute_normals = NormalGenerator(self.run_opts.image_height // 2, self.run_opts.image_width // 2)

        if self.run_opts.feature_volume_type == "simple_cost_volume":
            self.cost_volume = CostVolumeManager(
                matching_height=self.run_opts.image_height // (2 ** (self.run_opts.matching_scale + 1)),
                matching_width=self.run_opts.image_width // (2 ** (self.run_opts.matching_scale + 1)),
                num_depth_bins=self.run_opts.matching_num_depth_bins,
            )
        elif self.run_opts.feature_volume_type == "mlp_feature_volume":
            self.cost_volume = FeatureVolumeManager(
                matching_height=self.run_opts.image_height // (2 ** (self.run_opts.matching_scale + 1)),
                matching_width=self.run_opts.image_width // (2 ** (self.run_opts.matching_scale + 1)),
                num_depth_bins=self.run_opts.matching_num_depth_bins,
                matching_dim_size=self.run_opts.matching_feature_dims,
                num_reference_views=opts.model_num_views - 1
            )
        else:
            raise ValueError("Unrecognized option for feature volume type!")

        if "resnet" == self.run_opts.matching_encoder_type:
            self.matching_model = ResnetMatchingEncoder(18, self.run_opts.matching_feature_dims)
        elif "fpn" == self.run_opts.matching_encoder_type:
            self.matching_model = FPNMatchingEncoder()
        else:
            raise ValueError("Unrecognized option for matching encoder type!")

        self.tensor_formatter = TensorFormatter()

    def compute_matching_feats(self, cur_image, ref_image, unbatched_matching_encoder_forward):
        if unbatched_matching_encoder_forward:
            all_frames_bm3hw = torch.cat([cur_image.unsqueeze(1), ref_image], dim=1)
            batch_size, num_views = all_frames_bm3hw.shape[:2]
            all_frames_B3hw = tensor_bM_to_B(all_frames_bm3hw)
            matching_feats = [self.matching_model(f) for f in all_frames_B3hw.split(1, dim=0)]
            matching_feats = torch.cat(matching_feats, dim=0)
            matching_feats = tensor_B_to_bM(matching_feats, batch_size=batch_size, num_views=num_views)

        else:
            # Compute matching features and batch them to reduce variance from batchnorm
            matching_feats = self.tensor_formatter(
                torch.cat([cur_image.unsqueeze(1), ref_image], dim=1),
                apply_func=self.matching_model)

        matching_cur_feats = matching_feats[:, 0]
        matching_ref_feats = matching_feats[:, 1:].contiguous()

        return matching_cur_feats, matching_ref_feats

    def forward(self, phase, cur_data, ref_data, unbatched_matching_encoder_forward=False, return_mask=False):

        cur_image = cur_data["image_b3hw"]
        ref_image = ref_data["image_b3hw"]
        ref_K = ref_data[f"K_s{self.run_opts.matching_scale}_b44"]
        cur_invK = cur_data[f"invK_s{self.run_opts.matching_scale}_b44"]
        ref_cam_T_world = ref_data["cam_T_world_b44"]
        ref_world_T_cam = ref_data["world_T_cam_b44"]

        cur_cam_T_world = cur_data["cam_T_world_b44"]
        cur_world_T_cam = cur_data["world_T_cam_b44"]

        # Compute ref_cam_T_cur_cam
        with torch.cuda.amp.autocast(False):
            ref_cam_T_cur_cam = ref_cam_T_world @ cur_world_T_cam.unsqueeze(1)
            cur_cam_T_ref_cam = cur_cam_T_world.unsqueeze(1) @ ref_world_T_cam

        flip_threshold = 0.5 if phase == "train" else 0.0
        flip = torch.rand(1).item() < flip_threshold

        if flip:
            cur_image = torch.flip(cur_image, (-1,))
            ref_image = torch.flip(ref_image, (-1,))

        # Compute image features
        cur_feats = self.encoder(cur_image)

        # Compute matching features
        matching_cur_feats, matching_ref_feats = self.compute_matching_feats(
            cur_image, ref_image, unbatched_matching_encoder_forward)

        if flip:
            matching_cur_feats = torch.flip(matching_cur_feats, (-1,))
            matching_ref_feats = torch.flip(matching_ref_feats, (-1,))

        # Get min and max depth to the right shape, device and dtype
        min_depth = torch.tensor(self.run_opts.min_matching_depth).type_as(ref_K).view(1, 1, 1, 1)
        max_depth = torch.tensor(self.run_opts.max_matching_depth).type_as(ref_K).view(1, 1, 1, 1)

        # Compute the cost volume
        cost_volume, lowest_cost, _, overall_mask_bhw = self.cost_volume(cur_feats=matching_cur_feats,
                                                       ref_feats=matching_ref_feats,
                                                       ref_poses=ref_cam_T_cur_cam,
                                                       inv_ref_poses=cur_cam_T_ref_cam,
                                                       ref_Ks=ref_K,
                                                       cur_invK=cur_invK,
                                                       min_depth=min_depth,
                                                       max_depth=max_depth,
                                                       return_mask=return_mask)

        if flip:
            cost_volume = torch.flip(cost_volume, (-1,))
        
        # Encoder the cost volume in multiscale features
        if self.run_opts.cv_encoder_type == "multi_scale_encoder":
            cost_volume_features = self.cost_volume_net(cost_volume, cur_feats[self.run_opts.matching_scale:])
            cur_feats = cur_feats[:self.run_opts.matching_scale] + cost_volume_features

        # Decode into depth
        depth_outputs = self.depth_decoder(cur_feats)

        # cast to float for stability, since fp16 log/exp are not particularly precise
        for k in list(depth_outputs.keys()):
            log_depth = depth_outputs[k].float()

            if flip:
                log_depth = torch.flip(log_depth, (-1,))

            depth_outputs[k] = log_depth
            depth_outputs[k.replace("log_", "")] = torch.exp(log_depth)

        depth_outputs["lowest_cost_b1hw"] = lowest_cost
        depth_outputs["overall_mask_bhw"] = overall_mask_bhw

        return depth_outputs

    def compute_losses(self, cur_data, ref_data, outputs):

        depth_gt = cur_data["depth_b1hw"]
        normals_gt = cur_data["normals_b3hw"]
        mask_b = cur_data["mask_b_b1hw"]
        mask = cur_data["mask_b1hw"]
        depth_pred = outputs["depth_pred_s0_b1hw"]
        log_depth_pred = outputs["log_depth_pred_s0_b1hw"]
        normals_pred = outputs["normals_pred_b3hw"]

        log_depth_gt = torch.log(depth_gt)
        found_scale = False
        ms_loss = 0
        for i in range(4):
            if f"log_depth_pred_s{i}_b1hw" in outputs:
                log_depth_pred_resized = F.interpolate(outputs[f"log_depth_pred_s{i}_b1hw"], size=depth_gt.shape[-2:], mode="nearest")
                ms_loss += self.ms_loss_fn(log_depth_gt[mask_b], log_depth_pred_resized[mask_b]) / 2 ** i
                found_scale = True

        if not found_scale:
            raise Exception("Could not find a valid scale to compute si loss!")

        grad_loss = self.grad_loss(depth_gt, depth_pred)
        abs_loss = self.abs_loss(depth_gt[mask_b], depth_pred[mask_b])
        si_loss = self.si_loss(log_depth_gt[mask_b], log_depth_pred[mask_b])

        mask_b_limit = torch.logical_and(mask_b, depth_pred > 0.1)
        inv_abs_loss = self.abs_loss(1 / depth_gt[mask_b_limit], 1 / depth_pred[mask_b_limit])

        log_l1_loss = self.abs_loss(log_depth_gt[mask_b], log_depth_pred[mask_b])
        normals_loss = self.normals_loss(normals_gt, normals_pred)
        mv_loss = self.mv_depth_loss(depth_pred_b1hw=depth_pred,
                                     cur_depth_b1hw=depth_gt,
                                     ref_depth_bk1hw=ref_data["depth_b1hw"],
                                     cur_invK_b44=cur_data[f"invK_s0_b44"],
                                     ref_K_bk44=ref_data[f"K_s0_b44"],
                                     cur_world_T_cam_b44=cur_data["world_T_cam_b44"],
                                     ref_cam_T_world_bk44=ref_data["cam_T_world_b44"])

        loss = ms_loss + 1.0 * grad_loss + 1.0 * normals_loss + 0.2 * mv_loss

        losses = {
            "loss": loss,
            "si_loss": si_loss,
            "grad_loss": grad_loss,
            "abs_loss": abs_loss,
            "normals_loss": normals_loss,
            "ms_loss": ms_loss,
            "inv_abs_loss": inv_abs_loss,
            "log_l1_loss": log_l1_loss,
        }
        return losses

    def step(self, phase, batch, batch_idx):

        cur_data, ref_data = batch

        outputs = self(phase, cur_data, ref_data)

        depth_pred = outputs["depth_pred_s0_b1hw"]
        depth_pred_lr = outputs["depth_pred_s3_b1hw"]
        cv_min = outputs["lowest_cost_b1hw"]

        depth_gt = cur_data["depth_b1hw"]
        mask = cur_data["mask_b1hw"]
        mask_b = cur_data["mask_b_b1hw"]

        normals_gt = self.compute_normals(depth_gt, cur_data["invK_s0_b44"])
        cur_data["normals_b3hw"] = normals_gt

        normals_pred = self.compute_normals(depth_pred, cur_data["invK_s0_b44"])
        outputs["normals_pred_b3hw"] = normals_pred

        losses = self.compute_losses(cur_data, ref_data, outputs)

        is_train = phase == "train"

        with torch.inference_mode():
            if is_train and self.global_step % self.trainer.log_every_n_steps == 0:
                for i in range(4):
                    mask_i = mask[i].float().cpu()
                    depth_gt_viz_i, vmin, vmax = colormap_image(depth_gt[i].float().cpu(), mask_i, return_vminvmax=True)
                    depth_pred_viz_i = colormap_image(depth_pred[i].float().cpu(), vmin=vmin, vmax=vmax)
                    cv_min_viz_i = colormap_image(cv_min[i].unsqueeze(0).float().cpu(), vmin=vmin, vmax=vmax)
                    depth_pred_lr_viz_i = colormap_image(depth_pred_lr[i].float().cpu(), vmin=vmin, vmax=vmax)

                    image_i = TF.normalize(
                        tensor=cur_data["image_b3hw"][i],
                        mean=(-2.11790393, -2.03571429, -1.80444444),
                        std=(4.36681223, 4.46428571, 4.44444444))

                    self.logger.experiment.add_image(f'image/{i}', image_i, self.global_step)
                    self.logger.experiment.add_image(f'depth_gt/{i}', depth_gt_viz_i, self.global_step)
                    self.logger.experiment.add_image(f'depth_pred/{i}', depth_pred_viz_i, self.global_step)
                    self.logger.experiment.add_image(f'depth_pred_lr/{i}', depth_pred_lr_viz_i, self.global_step)
                    self.logger.experiment.add_image(f'normals_gt/{i}', 0.5 * (1 + normals_gt[i]), self.global_step)
                    self.logger.experiment.add_image(f'normals_pred/{i}', 0.5 * (1 + normals_pred[i]), self.global_step)
                    self.logger.experiment.add_image(f'cv_min/{i}', cv_min_viz_i, self.global_step)

                self.logger.experiment.flush()

            for loss_name, loss_val in losses.items():
                self.log(f'{phase}/{loss_name}', loss_val, sync_dist=True, on_step=is_train, on_epoch=not is_train)

            if phase == "train" or not self.run_opts.high_res_validation:
                metrics = compute_depth_metrics(depth_gt[mask_b], depth_pred[mask_b])
            else:
                # if we are validating or testing, we want to upscale our predictions to full-size and compare against
                # the GT depth map, so that metrics are comparable across resolutions
                full_size_depth_gt = cur_data["full_res_depth_b1hw"]
                full_size_mask_b = cur_data["full_res_mask_b_b1hw"]
                full_size_pred = F.interpolate(depth_pred, full_size_depth_gt.size()[-2:],
                                               mode="bilinear", align_corners=False)
                metrics = compute_depth_metrics(full_size_depth_gt[full_size_mask_b], full_size_pred[full_size_mask_b])

            for metric_name, metric_val in metrics.items():
                self.log(f'{phase}_metrics/{metric_name}', metric_val, sync_dist=True, on_step=is_train, on_epoch=not is_train)

        return losses["loss"]

    def training_step(self, batch, batch_idx):
        return self.step("train", batch, batch_idx)

    def validation_step(self, batch, batch_idx):
        return self.step("val", batch, batch_idx)

    def configure_optimizers(self):
        optimizer = torch.optim.AdamW(self.parameters(), lr=self.run_opts.lr, weight_decay=self.run_opts.wd)
        def lr_lambda(step):
            if step < 70000:
                return 1
            elif step < 80000:
                return .1
            else:
                return .01
        lr_scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)
        return {"optimizer": optimizer, "lr_scheduler": {"scheduler": lr_scheduler, "interval": "step"}}
