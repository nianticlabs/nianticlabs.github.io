import os
from pathlib import Path

import kornia
import torch
from torch import nn


def copy_code_state(path):
    """Copies the code directory into the path specified using rsync. It will use a .gitignore file
    to exclude files in rsync."""
    # use .gitignore to remove junk

    # create dir
    Path(os.path.join(path)).mkdir(parents=True, exist_ok=True)

    # preserve modification times in rsync
    rsync_command = (
        f"rsync -art --exclude-from='./.gitignore' --exclude '.git' . {path}"
    )
    os.system(rsync_command)

def readlines(filepath):
    with open(filepath, 'r') as f:
        lines = f.read().splitlines()
    return lines


def find_color_small_file_paths(main_path):
    # returns POSIX paths, so be careful!
    paths = list(Path(main_path).rglob('*.color.small.jpg'))
    return paths



def normalize_depth_single(depth_11hw, mask_11hw, robust=False):

    if mask_11hw is not None:
        valid_depth_vals_N = depth_11hw.masked_select(mask_11hw)
    else:
        valid_depth_vals_N = torch.flatten(depth_11hw)

    num_valid_pix = valid_depth_vals_N.nelement()
    num_percentile_pix = num_valid_pix // 10

    if num_valid_pix == 0:
        return depth_11hw

    sorted_depth_vals_N = torch.sort(valid_depth_vals_N)[0]
    depth_flat_N = sorted_depth_vals_N[num_percentile_pix:-num_percentile_pix]

    if depth_flat_N.nelement() == 0:
        depth_flat_N = valid_depth_vals_N

    if robust:
        depth_shift = depth_flat_N.median()
        depth_scale = torch.mean(torch.abs(depth_flat_N - depth_shift))
    else:
        depth_shift = depth_flat_N.mean()
        depth_scale = depth_flat_N.std()

    depth_norm = (depth_11hw - depth_shift) / depth_scale

    return depth_norm


def normalize_depth(depth_b1hw: torch.Tensor, mask_b1hw: torch.Tensor = None, robust: bool = False):

    depths_11hw = torch.split(depth_b1hw, 1, 0)
    masks_11hw = [None] * len(depths_11hw) if mask_b1hw is None else torch.split(mask_b1hw, 1, 0)

    depths_norm_11hw = [normalize_depth_single(d, m, robust) for d, m in zip(depths_11hw, masks_11hw)]

    return torch.cat(depths_norm_11hw, dim=0)


@torch.jit.script
def pyrdown(input_tensor: torch.Tensor, num_scales: int = 4):
    output = [input_tensor]
    for _ in range(num_scales - 1):
        down = kornia.filters.blur_pool2d(output[-1], 3)
        output.append(down)
    return output

@torch.jit.script
def minpyrdown(input_tensor: torch.Tensor, num_scales: int = 4):
    output = [input_tensor]
    for _ in range(num_scales - 1):
        down = 1 - nn.functional.max_pool2d(1 - output[-1], 3, stride=2, padding=1)
        output.append(down)
    return output

def upsample(x):
    """
    Upsample input tensor by a factor of 2
    """
    return nn.functional.interpolate(x, scale_factor=2, mode="bilinear", align_corners=False)

def batched_trace(mat_bNN):
    return mat_bNN.diagonal(offset=0, dim1=-1, dim2=-2).sum(-1)

def tensor_B_to_bM(tensor_BS, batch_size, num_views):
    """Unpacks a flattened tensor of tupled elements (BS) into bMS. Tuple size is M."""
    # S for wild card number of dims in the middle
    # tensor_bSM = tensor_BS.unfold(0, step=num_views, size=num_views)
    # tensor_bMS = tensor_bSM.movedim(-1, 1)
    tensor_bMS = tensor_BS.view([batch_size, num_views] + list(tensor_BS.shape[1:]))

    return tensor_bMS


def tensor_bM_to_B(tensor_bMS):
    """Packs an inflated tensor of tupled elements (bMS) into BS. Tuple size is M."""
    # S for wild card number of dims in the middle
    num_views = tensor_bMS.shape[1]
    num_batches = tensor_bMS.shape[0]

    tensor_BS = tensor_bMS.view([num_views * num_batches] + list(tensor_bMS.shape[2:]))

    return tensor_BS

def combine_dims(x, dim_begin, dim_end):
    """Views x with the dimensions from dim_begin to dim_end folded."""
    combined_shape = list(x.shape[:dim_begin]) + [-1] + list(x.shape[dim_end:])
    return x.view(combined_shape)


def to_gpu(input_dict):
    for k, v in input_dict.items():
        input_dict[k] = v.cuda().float()
    return input_dict