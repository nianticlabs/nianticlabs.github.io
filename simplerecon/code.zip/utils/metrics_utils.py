import torch
import numpy as np

def compute_depth_metrics(gt, pred, mult_a=False):
    """Computation of error metrics between predicted and ground truth depths
    """

    thresh = torch.max((gt / pred), (pred / gt))
    a_dict = {}
    a_dict["a5"] = (thresh < 1.05     ).float().mean()
    a_dict["a10"] = (thresh < 1.10     ).float().mean()
    a_dict["a25"] = (thresh < 1.25     ).float().mean()

    a_dict["a0"] = (thresh < 1.10     ).float().mean()
    a_dict["a1"] = (thresh < 1.25     ).float().mean()
    a_dict["a2"] = (thresh < 1.25 ** 2).float().mean()
    a_dict["a3"] = (thresh < 1.25 ** 3).float().mean()


    if mult_a:
        for key in a_dict:
            a_dict[key] = a_dict[key]*100

    rmse = (gt - pred) ** 2
    rmse = torch.sqrt(rmse.mean())

    rmse_log = (torch.log(gt) - torch.log(pred)) ** 2
    rmse_log = torch.sqrt(rmse_log.mean())

    abs_rel = torch.mean(torch.abs(gt - pred) / gt)

    sq_rel = torch.mean((gt - pred) ** 2 / gt)

    abs_diff = torch.mean(torch.abs(gt - pred))

    metrics_dict = {"abs_diff": abs_diff,
                    "abs_rel": abs_rel,
                    "sq_rel": sq_rel,
                    "rmse": rmse,
                    "rmse_log": rmse_log}
    metrics_dict.update(a_dict)

    return metrics_dict

def compute_depth_metrics_batched(gt_bN, pred_bN, valid_masks_bN, mult_a=False):
    """Computation of error metrics between predicted and ground truth depths, batched. Abuses nan behavior
    in torch.
    """

    gt_bN = gt_bN.clone()
    pred_bN = pred_bN.clone()

    gt_bN[~valid_masks_bN] = torch.nan
    pred_bN[~valid_masks_bN] = torch.nan

    thresh_bN = torch.max(torch.stack([(gt_bN / pred_bN), (pred_bN / gt_bN)], dim=2), dim=2)[0]
    a_dict = {}
    
    a_val = (thresh_bN < (1.0+0.05)     ).float()
    a_val[~valid_masks_bN] = torch.nan
    a_dict[f"a5"] = torch.nanmean(a_val, dim=1)

    a_val = (thresh_bN < (1.0+0.10)     ).float()
    a_val[~valid_masks_bN] = torch.nan
    a_dict[f"a10"] = torch.nanmean(a_val, dim=1) 

    a_val = (thresh_bN < (1.0+0.25)     ).float()
    a_val[~valid_masks_bN] = torch.nan
    a_dict[f"a25"] = torch.nanmean(a_val, dim=1)

    a_val = (thresh_bN < (1.0+0.10)     ).float()
    a_val[~valid_masks_bN] = torch.nan
    a_dict[f"a0"] = torch.nanmean(a_val, dim=1)

    a_val = (thresh_bN < (1.0+0.25)     ).float()
    a_val[~valid_masks_bN] = torch.nan
    a_dict[f"a1"] = torch.nanmean(a_val, dim=1)

    a_val = (thresh_bN < (1.0+0.25) ** 2).float()
    a_val[~valid_masks_bN] = torch.nan
    a_dict[f"a2"] = torch.nanmean(a_val, dim=1)

    a_val = (thresh_bN < (1.0+0.25) ** 3).float()
    a_val[~valid_masks_bN] = torch.nan
    a_dict[f"a3"] = torch.nanmean(a_val, dim=1)

    if mult_a:
        for key in a_dict:
            a_dict[key] = a_dict[key]*100

    rmse_bN = (gt_bN - pred_bN) ** 2
    rmse_b = torch.sqrt(torch.nanmean(rmse_bN, dim=1))

    rmse_log_bN = (torch.log(gt_bN) - torch.log(pred_bN)) ** 2
    rmse_log_b = torch.sqrt(torch.nanmean(rmse_log_bN, dim=1))

    abs_rel_b = torch.nanmean(torch.abs(gt_bN - pred_bN) / gt_bN, dim=1)

    sq_rel_b = torch.nanmean((gt_bN - pred_bN) ** 2 / gt_bN, dim=1)

    abs_diff_b = torch.nanmean(torch.abs(gt_bN - pred_bN), dim=1)

    metrics_dict = {"abs_diff": abs_diff_b,
                    "abs_rel": abs_rel_b,
                    "sq_rel": sq_rel_b,
                    "rmse": rmse_b,
                    "rmse_log": rmse_log_b}
    metrics_dict.update(a_dict)

    return metrics_dict

def compute_depth_metrics_dvmvs(gt, pred):
    # valid1 = gt >= 0.5
    # valid2 = gt <= max_depth
    # valid = valid1 & valid2
    # gt = gt[valid]
    # pred = pred[valid]

    differences = gt - pred
    abs_differences = torch.abs(differences)
    squared_differences = torch.square(differences)
    abs_error = torch.mean(abs_differences)
    abs_relative_error = torch.mean(abs_differences / gt)
    abs_inverse_error = torch.mean(torch.abs(1 / gt - 1 / pred))
    squared_relative_error = torch.mean(squared_differences / gt)
    rmse = torch.sqrt(torch.mean(squared_differences))
    ratios = torch.maximum(gt / pred, pred / gt)
    n_valid = torch.tensor(len(ratios), dtype=torch.float32)
    ratio_125 = torch.count_nonzero(ratios < 1.25) / n_valid
    ratio_125_2 = torch.count_nonzero(ratios < 1.25 ** 2) / n_valid
    ratio_125_3 = torch.count_nonzero(ratios < 1.25 ** 3) / n_valid
    return abs_relative_error, squared_relative_error, abs_error, rmse, ratio_125, ratio_125_2, ratio_125_3

class ResultsAverager():
    def __init__(self, exp_name, metrics_name):
        self.exp_name = exp_name
        self.metrics_name = metrics_name

        self.elem_metrics_list = []
        self.running_metrics = None
        self.running_count = 0

        self.final_computed_average = None

    def update_results(self, elem_metrics):
        """Updates running_metrics with incomming metrics while handling a running averaging."""

        self.elem_metrics_list.append(elem_metrics.copy())

        if self.running_metrics is None:
            self.running_metrics = elem_metrics.copy()
        else:
            for key in list(elem_metrics.keys()):
                self.running_metrics[key] = (self.running_metrics[key] * self.running_count + elem_metrics[key]) / (self.running_count + 1)

        self.running_count += 1

    def print_sheets_friendly(self, print_exp_name=True, include_metrics_names=False, running_metrics=True):
        """Pretty print for sheets copy/paste.
        
        include_names: print a row for metric names 
        """

        if print_exp_name:
            print(f"{self.exp_name}, {self.metrics_name}")

        if running_metrics:
            metrics_to_print = self.running_metrics
        else:
            metrics_to_print = self.final_metrics 

        metric_names_row = ""
        metrics_row = ""
        for k, v in metrics_to_print.items():
            metric_names_row += f"{k:8} "
            metric_string = f"{v:.4f},"
            metrics_row += f"{metric_string:8} "
        
        if include_metrics_names:
            print(metric_names_row)
        print(metrics_row)

    def pretty_print_results(self, print_exp_name=True, running_metrics=True):

        if running_metrics:
            metrics_to_print = self.running_metrics
        else:
            metrics_to_print = self.final_metrics 

        if print_exp_name:
            print(f"{self.exp_name}, {self.metrics_name}")
        for k, v in metrics_to_print.items():
            print(f"{k:8}: {v:.4f}")

    def compute_final_average(self, ignore_nans=False):
        """Computes final a final average on the metrics element list using numpy.
        
        This should be more accurate than running metrics as it's a single average vs multiple 
        multiplications and divisions."""

        self.final_metrics = {}

        for key in list(self.running_metrics.keys()):
            values = []
            for element in self.elem_metrics_list:
                if torch.is_tensor(element[key]):
                    values.append(element[key].cpu().numpy())
                else:
                    values.append(element[key])

            if ignore_nans:
                mean_value = np.nanmean(np.array(values))
            else:
                mean_value = np.array(values).mean()
            self.final_metrics[key] = mean_value

class BestsFormatter:
    '''From https://github.com/mohammed-amr/latexTableFormatter'''
    def __init__(self, metrics_list):
        # metrics list: names of metrics. 
        # comp_order: boolean list for metric sorting. True: higher is better. False: lower is better
        self.bests = {}
        self.second_bests = {}
        self.comp_order_dict = {}

        for index, metric in enumerate(metrics_list):
            self.bests[metric.name] = {}
            self.bests[metric.name]["value"] = None
            self.bests[metric.name]["method_name"] = ""

            self.second_bests[metric.name] = {}
            self.second_bests[metric.name]["value"] = None
            self.second_bests[metric.name]["method_name"] = ""

            self.comp_order_dict[metric.name] = metric.ascending_order

    def update_ordering(self, metric_name, value, method_name):
        if value is None:
            return

        if self.comp_order_dict[metric_name]:
            # ascending
            if self.bests[metric_name]["value"] is None or value > self.bests[metric_name]["value"]:
                # new first place. demote old first place and put in second place. store new best place
                self.second_bests[metric_name]["value"] = self.bests[metric_name]["value"]
                self.second_bests[metric_name]["method_name"] = self.bests[metric_name]["method_name"]
                self.bests[metric_name]["value"] = value
                self.bests[metric_name]["method_name"] = method_name
            else:
                # not better than first place.
                if self.second_bests[metric_name]["value"] is None or value > self.second_bests[metric_name]["value"]:
                    # new second place. store new second place
                    self.second_bests[metric_name]["value"] = value
                    self.second_bests[metric_name]["method_name"] = method_name

        else:
            #other way around. descending
            if self.bests[metric_name]["value"] is None or value < self.bests[metric_name]["value"]:
                # new first place. demote old first place and put in second place. store new best place
                self.second_bests[metric_name]["value"] = self.bests[metric_name]["value"]
                self.second_bests[metric_name]["method_name"] = self.bests[metric_name]["method_name"]
                self.bests[metric_name]["value"] = value
                self.bests[metric_name]["method_name"] = method_name
            else:
                # not better than first place.
                if self.second_bests[metric_name]["value"] is None or value < self.second_bests[metric_name]["value"]:
                    # new second place. store new second place
                    self.second_bests[metric_name]["value"] = value
                    self.second_bests[metric_name]["method_name"] = method_name
    
    def get_string(self, formatted_string, metric_name, method_name):
        if self.bests[metric_name]["method_name"] == method_name:
            return "\\cellcolor{firstcolor}" + formatted_string
        elif self.second_bests[metric_name]["method_name"] == method_name:
            return "\\cellcolor{secondcolor}" + formatted_string
        else:
            return formatted_string


class ResultStore():
    def __init__(self, metrics_list, method_name=None):
        self.metrics_dict = {}
        for metric in metrics_list:
            self.metrics_dict[metric.name] = None
        self.method_name = method_name
        self.metrics_list = metrics_list.copy()

    def set_metrics(self, metrics_dict):
        self.metrics_dict = metrics_dict.copy()

    def metrics_from_string(self, metrics_string, sep=",", empty_pos=""):
        split_list = metrics_string.split(sep)
        split_list = [float(metric_string.strip()) if metric_string != empty_pos else None for metric_string in split_list]

        for metric_ind, metric in enumerate(self.metrics_list):
            self.metrics_dict[metric.name] = split_list[metric_ind]

def build_latex_table_string(metrics_list, 
                            stored_results, 
                            bests_formatter,
                            missing_string="-", 
                            header_sep="\\hline",
                            row_sep = "",
                            after_method_name_string="",
                            ignore_ordering=False):

    # build headers
    overall_string = ""
    line_string = " & "
    for metric_ind, metric in enumerate(metrics_list):
        if metric.visibility_enable:
            line_string += metric.name + " & "
    line_string = line_string[:-3]

    overall_string += line_string + " \\\\" + "\n" + header_sep + "\n" 

    # loop to build table string. 
    for method_key, method_results in stored_results.items():
        line_string = method_results.method_name + after_method_name_string + " & "

        for metric_ind, metric in enumerate(metrics_list):
            if metric.visibility_enable:
                if method_results.metrics_dict[metric.name] is None:
                    metric_string = missing_string
                else:
                    formatted_string = metric.string_formatter % method_results.metrics_dict[metric.name]
                    metric_string = formatted_string.lstrip('0') if metric.strip_leading_zero else formatted_string
                    if not ignore_ordering and metric.orderable:
                        metric_string = bests_formatter.get_string(metric_string, metric.name, method_results.method_name)
            
                line_string += metric_string + " & "
            
        line_string = line_string[:-3]

        overall_string += line_string + " \\\\" + row_sep + "\n"

    return overall_string

class MetricInfo():
    def __init__(self, name, visibility_enable, string_formatter, ascending_order, strip_leading_zero=False, orderable=True):
        self.name=name
        self.visibility_enable = visibility_enable
        self.string_formatter = string_formatter
        self.ascending_order = ascending_order
        self.strip_leading_zero = strip_leading_zero
        self.orderable = orderable