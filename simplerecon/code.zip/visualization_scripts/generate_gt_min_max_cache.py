# %%
import sys

sys.path.append("/".join(sys.path[0].split("/")[:-1])) 

import importlib
import math
import os
import pickle
from pathlib import Path

import moviepy.editor as mpy
import numpy as np
import options
import scipy
import torch
from datasets.scannet_dataset import ScannetDataset
from datasets.seven_scenes_dataset import SevenScenesDataset
from tqdm import tqdm
from utils.geometry_utils import NormalGenerator


def save_viz_video_frames(frame_list, path):

    clip = mpy.ImageSequenceClip(frame_list, fps=30)
    clip.write_videofile(path, verbose=False, logger=None)

    return

torch.set_grad_enabled(False)

option_handler = options.OptionsHandler()

option_handler.parse_and_merge_options(ignore_cl_args=False)

option_handler.pretty_print_options()



opts = option_handler.options

if opts.gpus == 0:
    print("Setting precision to 32 bits since --gpus is set to 0.")
    opts.precision = 32

# set precision to 32 bits.
opts.precision = 32

print("Setting batch size to 1.")
opts.batch_size = 1

# %%
# figure out what dataset
if opts.dataset == "scannet":

    with open(opts.dataset_scene_split_file) as file:
        scans = file.readlines()
        scans = [scan.strip() for scan in scans]

    if opts.single_scene_test_id is not None:
        scans = [opts.single_scene_test_id]

    dataset_class = ScannetDataset
    print(f"".center(80, "#"))
    print(f" ScanNet Dataset, number of scans: {len(scans)} ".center(80, "#"))
    print(f"".center(80, "#"))
    print("")


elif opts.dataset == "7scenes":
    
    with open(opts.dataset_scene_split_file) as file:
        scans = file.readlines()
        scans = [scan.strip() for scan in scans]

    if opts.single_scene_test_id is not None:
        scans = [opts.single_scene_test_id]

    dataset_class = SevenScenesDataset
    print(f"".center(80, "#"))
    print(f" 7Scenes Dataset, number of scans: {len(scans)} ".center(80, "#"))
    print(f"".center(80, "#"))
    print("")



else:
    raise ValueError("Not a recognized dataset.")


compute_normals_full = NormalGenerator(480, 640).cuda()
compute_normals = NormalGenerator(192, 256).cuda()

# %%

base_output_path = f"{opts.depth_output_base_path}/gt_min_max"

Path(base_output_path).mkdir(parents=True, exist_ok=True)

print(f"".center(80, "#"))
print(f" Getting Visualizations.")
print(f" Output directory: {base_output_path} ".center(80, "#"))
print(f"".center(80, "#"))
print("")

with torch.inference_mode():
    for scan in tqdm(scans):


        # set up dataset with current scan
        dataset = dataset_class(opts.dataset_path,
                                split="test",
                                mv_split_file_suffix=opts.mv_split_file_suffix,
                                test_scene_id=scan,
                                load_full_res_depth=False,
                                split_file_location=opts.split_file_location,
                                num_images_in_tuple=None,
                                shuffle_tuple=opts.shuffle_tuple,
                                load_full_res_color=False,
                                pass_frame_id=True,
                                include_full_depth_K=False)

        dataloader = torch.utils.data.DataLoader(dataset, 
                                                batch_size=32, 
                                                shuffle=False, 
                                                num_workers=12, 
                                                drop_last=False)


        vmin = torch.inf
        vmax = 0
        mins = []
        maxs = []
        for batch_ind, batch in enumerate(tqdm(dataloader)):
            cur_data, ref_data = batch

            maxs.append(torch.quantile(cur_data["depth_b1hw"].cuda()[cur_data["mask_b_b1hw"].cuda()], 0.98).squeeze().cpu())
            mins.append(torch.quantile(cur_data["depth_b1hw"].cuda()[cur_data["mask_b_b1hw"].cuda()], 0.02).squeeze().cpu())
        
        maxs = np.array(maxs)
        mins = np.array(mins)

        vmax = np.max(scipy.ndimage.gaussian_filter1d(maxs, sigma=1))
        vmin = np.min(scipy.ndimage.gaussian_filter1d(mins, sigma=1))


        limits = [vmin, vmax]
        print(scan, limits)

        with open(os.path.join(base_output_path, f"{scan}.pickle"), 'wb') as handle:
            pickle.dump(limits, handle)
