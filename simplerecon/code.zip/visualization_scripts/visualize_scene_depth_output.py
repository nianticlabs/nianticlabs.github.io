# %%
import sys

sys.path.append("/".join(sys.path[0].split("/")[:-1])) 

import os
import pickle
from pathlib import Path

import moviepy.editor as mpy
import numpy as np
import options
import timm
import torch
import torch.nn.functional as F
import torchvision.transforms.functional as TF
from datasets.scannet_dataset import ScannetDataset
from datasets.seven_scenes_dataset import SevenScenesDataset
from datasets.arkit_neucon import ARKitDataset

from PIL import Image
from tqdm import tqdm
from utils.geometry_utils import NormalGenerator
from utils.visualization_utils import colormap_image


def save_viz_video_frames(frame_list, path):

    clip = mpy.ImageSequenceClip(frame_list, fps=30)
    clip.write_videofile(path, verbose=False, logger=None)

    return

    
torch.set_grad_enabled(False)

option_handler = options.OptionsHandler()

option_handler.parse_and_merge_options(ignore_cl_args=False)

option_handler.pretty_print_options()
print("")


opts = option_handler.options

if opts.gpus == 0:
    print("Setting precision to 32 bits since --gpus is set to 0.")
    opts.precision = 32

# opts.mv_split_file_suffix = "_eight_view_deepvmvs_dense.txt"
# set precision to 32 bits.
opts.precision = 32

print("Setting batch size to 1.")
opts.batch_size = 1

# %%
# figure out what dataset
if opts.dataset == "scannet":

    with open(opts.dataset_scene_split_file) as file:
        scans = file.readlines()
        scans = [scan.strip() for scan in scans]

    if opts.single_scene_test_id is not None:
        scans = [opts.single_scene_test_id]

    dataset_class = ScannetDataset
    print(f"".center(80, "#"))
    print(f" ScanNet Dataset, number of scans: {len(scans)} ".center(80, "#"))
    print(f"".center(80, "#"))
    print("")


elif opts.dataset == "7scenes":
    
    with open(opts.dataset_scene_split_file) as file:
        scans = file.readlines()
        scans = [scan.strip() for scan in scans]

    if opts.single_scene_test_id is not None:
        scans = [opts.single_scene_test_id]

    dataset_class = SevenScenesDataset
    print(f"".center(80, "#"))
    print(f" 7Scenes Dataset, number of scans: {len(scans)} ".center(80, "#"))
    print(f"".center(80, "#"))
    print("")

elif opts.dataset == "arkit_neucon":
    
    scans = ["b5f1"]

    if opts.single_scene_test_id is not None:
        scans = [opts.single_scene_test_id]

    dataset_class = ARKitDataset
    print(f"".center(80, "#"))
    print(f" ARKitDataset Dataset, number of scans: {len(scans)} ".center(80, "#"))
    print(f"".center(80, "#"))
    print("")

else:
    raise ValueError("Not a recognized dataset.")

output_path = f"{opts.depth_output_base_path}{opts.name}/scans_test/"


compute_normals_full = NormalGenerator(480, 640).cuda()
compute_normals = NormalGenerator(192, 256).cuda()

# %%
base_output_path = f"{opts.depth_output_base_path}{opts.name}_raw/"

Path(os.path.join(base_output_path, "visualizations")).mkdir(parents=True, exist_ok=True)

print(f"".center(80, "#"))
print(f" Getting Visualizations.")
print(f"Output directory: {base_output_path} ".center(80, "#"))
print(f"".center(80, "#"))
print("")

with torch.inference_mode():
    for scan in tqdm(scans):

        if os.path.exists(os.path.join(opts.depth_output_base_path, "gt_min_max", f"{scan}.pickle")):
            with open(os.path.join(opts.depth_output_base_path, "gt_min_max", f"{scan}.pickle"), 'rb') as handle:
                limits = pickle.load(handle)
        else:
            print(f"".center(80, "#"))
            print(f" No GT min/max found. Using min=0m and max=5m ".center(80, "#"))
            print(f"".center(80, "#"))
            print("")
            limits = [0,5]

        vmin, vmax = limits

        dataset = dataset_class(opts.dataset_path,
                                split="test",
                                mv_split_file_suffix=opts.mv_split_file_suffix,
                                test_scene_id=scan,
                                load_full_res_depth=True,
                                split_file_location=opts.split_file_location,
                                num_images_in_tuple=None,
                                shuffle_tuple=opts.shuffle_tuple,
                                load_full_res_color=True,
                                pass_frame_id=True,
                                include_full_depth_K=True)

        dataloader = torch.utils.data.DataLoader(dataset, 
                                                batch_size=opts.batch_size, 
                                                shuffle=False, 
                                                num_workers=opts.num_workers, 
                                                drop_last=False)
        output_image_list=[]
        for batch_ind, batch in enumerate(tqdm(dataloader)):
 
            cur_data, ref_data = batch
            frame_id = int(cur_data["frame_id"][0])

            invK_full_depth_b44 = cur_data["invK_full_depth_b44"].cuda()
            invK_s0_b44 = cur_data["invK_s0_b44"].cuda()

            pickled_path = os.path.join(base_output_path, "scans_test", scan, f"{frame_id}.pickle")

            try:
                with open(pickled_path, 'rb') as handle:
                    outputs = pickle.load(handle)
            except:
                continue

            ############################## RGB ##############################
            main_color_3hw = F.upsample(cur_data["full_res_color_b3hw"].cuda(), 
                                            size=(480,640), mode="bilinear", align_corners=False)[0]
            main_color_3hw = TF.normalize(
            tensor=main_color_3hw,
            mean=(-2.11790393, -2.03571429, -1.80444444),
            std=(4.36681223, 4.46428571, 4.44444444))


            image_i = TF.normalize(
            tensor=torch.tensor(ref_data['image_b3hw'][0].cuda()),
            mean=(-2.11790393, -2.03571429, -1.80444444),
            std=(4.36681223, 4.46428571, 4.44444444))
            lower_image_panel_b3hw = F.upsample(image_i, 
                                            size=(69,91), mode="bilinear", align_corners=False)
            lower_image_panel_13hw_list = lower_image_panel_b3hw.split(split_size=1, dim=0)
            lower_image_panel_3hw = torch.cat(lower_image_panel_13hw_list, dim=3).squeeze()

            # output_image[:,480-lower_image_panel_3hw.shape[1]:480,0:lower_image_panel_3hw.shape[2]]
            ############################## Our depth and normals ##############################
            depth_pred_s0_b1hw = outputs["depth_pred_s0_b1hw"].cuda()
            our_depth_3hw = colormap_image(depth_pred_s0_b1hw.squeeze(0), vmin=vmin, vmax=vmax)

            normals_b3hw = compute_normals(depth_pred_s0_b1hw, invK_s0_b44)
            our_normals_3hw = 0.5 * (1 + normals_b3hw).squeeze(0)

            lowest_cost_b1hw = outputs["lowest_cost_b1hw"].cuda()
            lowest_cost_3hw = colormap_image(lowest_cost_b1hw, vmin=vmin, vmax=vmax)

            ############################## gt depth ##############################
            depth_gt_3hw = colormap_image(cur_data["full_res_depth_b1hw"][0].cuda(), cur_data["full_res_mask_b1hw"][0].cuda(), vmin=vmin, vmax=vmax)
            normals_b3hw = compute_normals_full(cur_data["full_res_depth_b1hw"].cuda(), invK_full_depth_b44)
            gt_normals_3hw = 0.5 * (1 + normals_b3hw).squeeze(0)
            gt_normals_3hw = torch.nan_to_num(gt_normals_3hw)

            ############################## assemble ##############################

            # gt column
            target_height = 480
            buffer_gap = 4
            horizontal_buffer = torch.ones(depth_gt_3hw.shape[0], buffer_gap, depth_gt_3hw.shape[2]).cuda()
            gt_column = [depth_gt_3hw, horizontal_buffer, gt_normals_3hw]
            gt_column_np = [element.permute(1,2,0).cpu().detach().numpy() * 255 for element in gt_column]
            gt_column_np = np.uint8(np.concatenate(gt_column_np, axis=0))

            # our column
            target_width = int((target_height/192) * 256)
            our_depth_3hw = F.interpolate(our_depth_3hw.unsqueeze(0), size=(target_height, target_width), mode="nearest").squeeze()
            our_normals_3hw = F.interpolate(our_normals_3hw.unsqueeze(0), size=(target_height, target_width), mode="nearest").squeeze()
            our_lowest_cost_3hw = F.interpolate(lowest_cost_3hw.unsqueeze(0), size=(target_height, target_width), mode="nearest").squeeze()


            horizontal_buffer = torch.ones(our_depth_3hw.shape[0], buffer_gap, our_depth_3hw.shape[2]).cuda()
            our_column = [our_depth_3hw, horizontal_buffer, our_normals_3hw]
            our_column_np = [element.permute(1,2,0).cpu().detach().numpy() * 255 for element in our_column]
            our_column_np = np.uint8(np.concatenate(our_column_np, axis=0))

            # assemble results
            horizontal_buffer = np.ones((target_height*2 + buffer_gap, buffer_gap, 3)) * 255
            
            results_list = [our_column_np, horizontal_buffer, gt_column_np]  
            results_panel_np = np.uint8(np.concatenate(results_list, axis=1))

            # shape image and ref images
            lower_image_panel_3hw = F.pad(lower_image_panel_3hw, (0,main_color_3hw.shape[2] - lower_image_panel_3hw.shape[2],0,0,0,0), value=0.0)
            main_color_3hw[:, main_color_3hw.shape[1] - lower_image_panel_3hw.shape[1]:, :] = lower_image_panel_3hw


            # append image to lowest cost
            horizontal_buffer = torch.ones(main_color_3hw.shape[0], buffer_gap, main_color_3hw.shape[2]).cuda()
            color_panel = torch.cat([our_lowest_cost_3hw, horizontal_buffer, main_color_3hw], dim = 1)      
            color_panel_np = np.uint8(color_panel.permute(1,2,0).cpu().detach().numpy() * 255)

            assert color_panel_np.shape[0] == results_panel_np.shape[0]

            # final assemble
            vertical_buffer = np.ones((color_panel_np.shape[0], buffer_gap, 3)) * 255
            final_image_list = [color_panel_np, vertical_buffer, results_panel_np]
            final_image_np = np.concatenate(final_image_list, axis=1)

            # pad for compression
            pad_height = 16 - (final_image_np.shape[0] % 16) if final_image_np.shape[0] % 16 !=0 else 0
            pad_width = 16 - (final_image_np.shape[1] % 16) if final_image_np.shape[1] % 16 !=0 else 0
            final_image_np = np.uint8(np.pad(final_image_np, pad_width=((0, pad_height), (0, pad_width), (0, 0)), constant_values=255))

            output_image_list.append(final_image_np)

        save_viz_video_frames(output_image_list, os.path.join(base_output_path, "visualizations", f"{scan}.mp4"))

# %%
