import os
from pathlib import Path

import pickle
import numpy as np
import open3d as o3d
import torch
import torch.nn.functional as F
import torchvision.transforms.functional as TF
import trimesh
from tqdm import tqdm

import experiment_modules.DepthModel as DepthModel
import options
from datasets.scannet_dataset import ScannetDataset
from datasets.seven_scenes_dataset import SevenScenesDataset
from datasets.arkit_neucon import ARKitDataset
from datasets.vdr_dataset import VDRDataset
from datasets.scanniverse_dataset import ScanniverseDataset
from tools.tsdf import TSDF, TSDFFuser
from tools import fusers_helper
from utils.generic_utils import (readlines, to_gpu)
from utils.metrics_utils import ResultsAverager, compute_depth_metrics_batched
import tools.torch_point_cloud_fusion as torch_point_cloud_fusion



def main(opts):

    # set precision to 32 bits.
    opts.precision = 32

    # figure out what dataset
    if opts.dataset == "scannet":

        with open(opts.dataset_scene_split_file) as file:
            scans = file.readlines()
            scans = [scan.strip() for scan in scans]
        
        if opts.single_scene_test_id is not None:
            scans = [opts.single_scene_test_id]

        dataset_class = ScannetDataset
        print(f"".center(80, "#"))
        print(f" ScanNet Dataset, number of scans: {len(scans)} ".center(80, "#"))
        print(f"".center(80, "#"))
        print("")


    elif opts.dataset == "arkit_neucon":
        
        with open(opts.dataset_scene_split_file) as file:
            scans = file.readlines()
            scans = [scan.strip() for scan in scans]

        if opts.single_scene_test_id is not None:
            scans = [opts.single_scene_test_id]

        dataset_class = ARKitDataset
        print(f"".center(80, "#"))
        print(f" ARKitDataset Dataset, number of scans: {len(scans)} ".center(80, "#"))
        print(f"".center(80, "#"))
        print("")

    elif opts.dataset == "vdr":


        # scans = [
        #     "14_03_2022-08_46_35_5174EA15-24CC-4DA1-8DA6-3F8AD8760B84_map_lidar_o0",
        #     "14_03_2022-08_47_59_4DBD5DBB-BA1E-42C4-A8EB-1B79629452A9_map_lidar_o0",
        #     "25_05_2022-08_55_04_8778696F-C0D0-4231-ADF5-ED12A88E3327_map_lidar_o1",
        #     "25_05_2022-09_00_29_B7376481-0D65-41DC-AB47-2A7D232D115E_map_lidar_o1",
        #     "25_05_2022-08_56_45_6643E310-62E5-4A73-B6CD-E5D4EED76AC6_map_lidar_o1",
        #     "25_05_2022-08_58_51_6F37DD97-58CE-47B9-9BB1-1823A435E7F6_map_lidar_o1",
        #     "25_05_2022-09_04_18_AF58D649-38EE-4BBC-BF66-BE60B9D442C3_map_lidar_o1",
        #     "25_05_2022-09_06_06_37F187CF-5699-43BB-8FF1-E85012E0B6D1_map_lidar_o1",
        #       "27_05_2022-14_33_45_B3245BFA-15EB-46A3-8F5D-681BF07235AD_map_lidar_o0",
                # "27_05_2022-14_34_47_AA675632-C823-434C-8778-80ACC092FE96_map_lidar_o0"]

        scans = ["27_05_2022-14_33_45_B3245BFA-15EB-46A3-8F5D-681BF07235AD_map_lidar_o0"]


        if opts.single_scene_test_id is not None:
            scans = [opts.single_scene_test_id]

        dataset_class = VDRDataset
        print(f"".center(80, "#"))
        print(f" VDR Dataset, number of scans: {len(scans)} ".center(80, "#"))
        print(f"".center(80, "#"))
        print("")

    elif opts.dataset == "scanniverse":

        with open(opts.dataset_scene_split_file) as file:
            scans = file.readlines()
            scans = [scan.strip() for scan in scans]

        if opts.single_scene_test_id is not None:
            scans = [opts.single_scene_test_id]

        dataset_class = ScanniverseDataset
        print(f"".center(80, "#"))
        print(f" ScanniverseDataset Dataset, number of scans: {len(scans)} ".center(80, "#"))
        print(f"".center(80, "#"))
        print("")


    elif opts.dataset == "7scenes":
        
        with open(opts.dataset_scene_split_file) as file:
            scans = file.readlines()
            scans = [scan.strip() for scan in scans]

        if opts.single_scene_test_id is not None:
            scans = [opts.single_scene_test_id]

        dataset_class = SevenScenesDataset
        print(f"".center(80, "#"))
        print(f" 7Scenes Dataset, number of scans: {len(scans)} ".center(80, "#"))
        print(f"".center(80, "#"))
        print("")

    else:
        raise ValueError("Not a recognized dataset.")

    
    N_CONSISTENT_THRESH = opts.n_consistent_thresh
    Z_THRESH = opts.pc_fusion_z_thresh
    VOXEL_DOWNSAMPLE = opts.voxel_downsample


    output_path = f"{opts.fusion_output_base_path}{opts.name}_pc_{N_CONSISTENT_THRESH}_{Z_THRESH}_{VOXEL_DOWNSAMPLE}_{opts.fusion_max_depth}/scans_test/"
    
    Path(os.path.join(output_path)).mkdir(parents=True, exist_ok=True)
    print(f"".center(80, "#"))
    print(f" Running Fusion! Using {opts.depth_fuser} ".center(80, "#"))
    print(f"Output directory: {output_path} ".center(80, "#"))
    print(f"".center(80, "#"))
    print("")


    model = DepthModel.DepthModel.load_from_checkpoint(opts.load_weights_from_checkpoint, args=None)
    model = model.cuda().eval()

    all_frame_metrics = None
    all_scene_metrics = None

    all_frame_metrics = ResultsAverager(opts.name, f"frame metrics")
    all_scene_metrics = ResultsAverager(opts.name, f"scene metrics")

    with torch.inference_mode():
        for scan in tqdm(scans):
            
            # set up dataset with current scan
            dataset = dataset_class(opts.dataset_path,
                                    split="test",
                                    mv_split_file_suffix=opts.mv_split_file_suffix,
                                    test_scene_id=scan,
                                    load_full_res_depth=True,
                                    split_file_location=opts.split_file_location,
                                    num_images_in_tuple=None,
                                    shuffle_tuple=opts.shuffle_tuple,
                                    load_full_res_color=opts.fuse_color and opts.run_fusion,
                                    include_full_depth_K=True,
                                    skip_frames=opts.skip_frames,
                                    image_width=opts.image_width,
                                    image_height=opts.image_height,
                                    pass_frame_id=True)

            dataloader = torch.utils.data.DataLoader(dataset, 
                                                    batch_size=opts.batch_size, 
                                                    shuffle=False, 
                                                    num_workers=opts.num_workers, 
                                                    drop_last=False)

            # initialize scene averager
            scene_frame_metrics = ResultsAverager(opts.name, f"scene {scan} metrics")

            images_list = []
            depths_list = []
            poses_list = []
            K_list = []

            for batch in tqdm(dataloader):
                
                # get data, move to GPU
                cur_data, ref_data = batch

                cur_data = to_gpu(cur_data)
                ref_data = to_gpu(ref_data)

                outputs = model("test", cur_data, ref_data, unbatched_matching_encoder_forward=True, return_mask=True)
                depth_pred = outputs["depth_pred_s0_b1hw"]
                depth_gt = cur_data["full_res_depth_b1hw"]

                upsampled_depth_pred_b1hw = F.upsample(depth_pred, size=(depth_gt.shape[-2], depth_gt.shape[-1]), mode="nearest")

                # inf max depth matches DVMVS metrics
                valid_mask_b = (depth_gt > 0.5)# & (depth_gt < 10)

                # No valid points in this sample
                if (~valid_mask_b).all():
                    continue
                
                # compute metrics
                metrics_b_dict = compute_depth_metrics_batched(depth_gt.flatten(start_dim=1).float(), 
                                                            upsampled_depth_pred_b1hw.flatten(start_dim=1).float(), 
                                                            valid_mask_b.flatten(start_dim=1),
                                                            mult_a=True)

                # go over batch and get metrics frame by frame to update the averagers 
                for element_index in range(depth_gt.shape[0]):
                    element_metrics = {}
                    if (~valid_mask_b[element_index]).all():
                        continue
                    for key in list(metrics_b_dict.keys()):
                        element_metrics[key] = metrics_b_dict[key][element_index]
                    
                    # both scene and frame averagers
                    scene_frame_metrics.update_results(element_metrics)
                    all_frame_metrics.update_results(element_metrics)

                cur_data["full_res_color_b3hw"] = F.upsample(cur_data["full_res_color_b3hw"], size=(480, 640), mode="bilinear")
                image_i = cur_data["full_res_color_b3hw"][0].cuda()
                image_i = TF.normalize(
                tensor=image_i,
                mean=(-2.11790393, -2.03571429, -1.80444444),
                std=(4.36681223, 4.46428571, 4.44444444))

                images_list.append(image_i.unsqueeze(0))

                depth_pred_s0_b1hw = outputs["depth_pred_s0_b1hw"].cuda()

                depth_pred_s0_b1hw[depth_pred_s0_b1hw > opts.fusion_max_depth] = 0

                lowest_cost_b1hw = outputs["lowest_cost_b1hw"].cuda()
                upsampled_depth_pred = F.upsample(depth_pred_s0_b1hw, size=(480, 640), mode="nearest")

                depths_list.append(upsampled_depth_pred)

                poses_list.append(cur_data["cam_T_world_b44"].clone())
                K_list.append(cur_data["K_full_depth_b44"].clone())

            depths_preds_bhw = torch.cat(depths_list, dim=0).squeeze(1)
            poses_b44 = torch.cat(poses_list, dim=0)
            image_bhw3 = torch.cat(images_list, dim=0).permute(0,2,3,1)*255
            K_b33 = torch.cat(K_list, dim=0)[:,:3,:3]

            n_imgs = depths_preds_bhw.shape[0]

            fused_pts, fused_rgb, _ = torch_point_cloud_fusion.process_scene(
                depths_preds_bhw, image_bhw3.to(torch.uint8), poses_b44,
                K_b33, Z_THRESH, N_CONSISTENT_THRESH)
            pcd_pred = o3d.geometry.PointCloud()
            pcd_pred.points = o3d.utility.Vector3dVector(fused_pts)
            pcd_pred.colors = o3d.utility.Vector3dVector(fused_rgb / 255.)
            pcd_pred = pcd_pred.voxel_down_sample(VOXEL_DOWNSAMPLE)

            pcd_filepath = os.path.join(output_path, f"{scan}_pc_{N_CONSISTENT_THRESH}_{Z_THRESH}_{VOXEL_DOWNSAMPLE}_{opts.fusion_max_depth}.ply")
            o3d.io.write_point_cloud(pcd_filepath, pcd_pred)

if __name__ == '__main__':
    torch.set_grad_enabled(False)

    option_handler = options.OptionsHandler()

    option_handler.parse_and_merge_options()

    option_handler.pretty_print_options()
    print("")


    opts = option_handler.options

    if opts.gpus == 0:
        print("Setting precision to 32 bits since --gpus is set to 0.")
        opts.precision = 32

    main(opts)
